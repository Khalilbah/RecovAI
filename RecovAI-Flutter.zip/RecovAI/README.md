# RecovAI — Flutter + Node.js Backend

تطبيق استشفاء رياضي مدعوم بـ Claude AI. يعمل على Android وiOS.

---

## 📁 هيكل المشروع

```
RecovAI/
├── flutter/          ← تطبيق Flutter (Android + iOS)
│   ├── lib/
│   │   ├── main.dart
│   │   ├── core/theme/app_theme.dart
│   │   ├── data/models/models.dart
│   │   ├── data/services/api_service.dart
│   │   └── presentation/
│   │       ├── providers/app_provider.dart
│   │       ├── widgets/shared_widgets.dart
│   │       └── screens/
│   │           ├── auth/   (welcome, login, register)
│   │           ├── home/   (home, main navigation)
│   │           ├── log/    (workout log + Claude AI plan)
│   │           ├── progress/
│   │           ├── settings/
│   │           └── admin/
│   └── pubspec.yaml
└── backend/          ← Node.js API Server
    ├── src/
    │   ├── app.js
    │   ├── config/database.js
    │   ├── middleware/auth.js
    │   ├── services/claudeService.js
    │   └── routes/index.js
    └── db/
        ├── migrate.js
        └── seed.js
```

---

## 🚀 تشغيل الـ Backend

```bash
cd backend
cp .env.example .env
# ✏️ ضع مفتاح Claude: ANTHROPIC_API_KEY=sk-ant-xxxx
npm install
npm run setup   # migrate + seed
npm run dev     # يشتغل على port 3000
```

**حسابات تجريبية:**
| الدور | البريد | كلمة المرور |
|-------|--------|------------|
| Admin | khalilbba39@gmail.com | khalilbba3439 |
| User  | ahmed@demo.com | demo123456 |

---

## 📱 تشغيل Flutter

```bash
cd flutter
flutter pub get
flutter run              # تشغيل على جهاز متصل
flutter run --release    # نسخة الإنتاج
```

**تغيير عنوان الـ Backend:**
في `lib/data/services/api_service.dart`:
```dart
static const String baseUrl = 'http://10.0.2.2:3000/api';
// Android Emulator: 10.0.2.2
// iOS Simulator:    localhost
// جهاز حقيقي:    http://IP-جهازك:3000/api
// Production:       https://your-server.com/api
```

---

## 🏗️ بناء APK (Android)

```bash
cd flutter

# APK مباشر (للتجربة)
flutter build apk --release
# الناتج: build/app/outputs/flutter-apk/app-release.apk

# App Bundle (للـ Play Store)
flutter build appbundle --release
```

---

## 🍎 بناء IPA (iOS)

```bash
cd flutter

# يحتاج Mac + Xcode + Apple Developer Account
flutter build ios --release

# أو باستخدام EAS (بدون Mac)
npm install -g eas-cli
eas build --platform ios
```

---

## 🤖 كيف يعمل Claude AI

```
Admin → يضيف تمارين + وصفات + نصائح للـ Backend
                ↓
User → يسجّل تمريناً في Flutter
                ↓
Flutter → POST /api/recovery/generate
                ↓
Backend → يجمع المكتبة كاملة + يرسلها لـ Claude
                ↓
Claude → يختار التمارين المناسبة + يشرحها بالتفصيل
                ↓
Flutter → يعرض الخطة الكاملة للمستخدم
```

> **بدون مفتاح Claude:** يعمل بـ Rules-Based تلقائياً

---

## 📡 API المتاحة

| Method | Endpoint | الوصف |
|--------|----------|-------|
| POST | /api/auth/register | إنشاء حساب |
| POST | /api/auth/login | تسجيل دخول |
| GET  | /api/auth/me | بيانات المستخدم |
| POST | /api/workouts | تسجيل تمرين |
| POST | /api/recovery/generate | **إنشاء خطة Claude AI** |
| GET  | /api/recovery/latest | آخر خطة |
| GET  | /api/exercises | مكتبة التمارين |
| GET  | /api/recipes | الوصفات |
| GET  | /api/admin/dashboard | إحصائيات (Admin) |
| GET  | /api/admin/users | قائمة المستخدمين (Admin) |

---

## 🌐 النشر على السيرفر

```bash
# على VPS/Railway/Render
cd backend
NODE_ENV=production
PORT=3000
JWT_SECRET=مفتاح_قوي_جداً
ANTHROPIC_API_KEY=sk-ant-xxxx
DB_PATH=/data/recovai.sqlite

npm install --production
npm run setup
npm start
```
