// db/migrate.js
const Database = require('better-sqlite3');
const path = require('path');
const fs   = require('fs');
require('dotenv').config();

const dbDir = path.resolve('./db');
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(path.resolve(process.env.DB_PATH || './db/recovai.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  first_name TEXT NOT NULL,
  last_name  TEXT NOT NULL DEFAULT '',
  email      TEXT NOT NULL UNIQUE,
  password   TEXT NOT NULL,
  role       TEXT NOT NULL DEFAULT 'user',
  age        INTEGER, weight REAL, height REAL, gender TEXT,
  activity_level TEXT DEFAULT 'متوسط',
  sport TEXT, photo_url TEXT, plan TEXT DEFAULT 'مجانية',
  plan_expiry TEXT, is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS workouts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sport TEXT NOT NULL, duration INTEGER NOT NULL,
  intensity TEXT NOT NULL, time_of_day TEXT DEFAULT 'مسائي',
  zones TEXT NOT NULL, notes TEXT,
  workout_date TEXT DEFAULT (date('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS recovery_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  workout_id INTEGER, recovery_score INTEGER, summary TEXT,
  stretching TEXT, hydration TEXT, sleep TEXT, nutrition TEXT,
  massage TEXT, warnings TEXT, ai_generated INTEGER DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS exercises (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'إطالة',
  duration TEXT, intensity TEXT DEFAULT 'خفيف',
  zones TEXT, icon TEXT DEFAULT '🧘',
  description TEXT, video_url TEXT, image_url TEXT,
  is_active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS nutrition_recipes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'بعد التمرين',
  prep_time TEXT, ingredients TEXT NOT NULL DEFAULT '[]',
  steps TEXT DEFAULT '[]', benefit TEXT,
  icon TEXT DEFAULT '🥗', image_url TEXT,
  is_active INTEGER DEFAULT 1, views INTEGER DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sleep_hydration_tips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
  sport_filter TEXT, intensity_filter TEXT,
  is_active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, body TEXT NOT NULL,
  type TEXT DEFAULT 'general', remind_at TEXT,
  is_read INTEGER DEFAULT 0, target TEXT DEFAULT 'user',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_workouts_user ON workouts(user_id);
CREATE INDEX IF NOT EXISTS idx_plans_user    ON recovery_plans(user_id);
CREATE INDEX IF NOT EXISTS idx_users_email   ON users(email);
`);

console.log('✅ Migration complete');
module.exports = db;
