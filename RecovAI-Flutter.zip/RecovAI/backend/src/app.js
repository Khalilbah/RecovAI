// src/app.js
require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const morgan  = require('morgan');
const routes  = require('./routes/index');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: '*', methods: ['GET','POST','PATCH','PUT','DELETE'] }));
app.use(express.json({ limit: '10mb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));
app.use('/api', routes);

app.get('/', (req, res) => res.json({
  name: 'RecovAI Backend', version: '1.0.0',
  flutter: 'Change API_BASE in lib/data/services/api_service.dart to your server URL'
}));

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ success: false, message: err.message || 'خطأ داخلي' });
});
// 404
app.use((req, res) => res.status(404).json({ success: false, message: 'المسار غير موجود' }));

app.listen(PORT, () => {
  console.log(`\n🚀 RecovAI Backend — Port ${PORT}`);
  console.log(`🤖 Claude AI: ${process.env.ANTHROPIC_API_KEY && process.env.ANTHROPIC_API_KEY !== 'sk-ant-your-key-here' ? '✅ Enabled' : '⚠️ Rules-based fallback'}\n`);
});

module.exports = app;
