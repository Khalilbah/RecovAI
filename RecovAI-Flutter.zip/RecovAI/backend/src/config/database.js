// src/config/database.js
const Database = require('better-sqlite3');
const path = require('path');
require('dotenv').config();

const db = new Database(path.resolve(process.env.DB_PATH || './db/recovai.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
module.exports = db;
