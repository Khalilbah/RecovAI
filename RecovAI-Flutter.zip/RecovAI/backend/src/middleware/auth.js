// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const db  = require('../config/database');

const authenticate = (req, res, next) => {
  const header = req.headers['authorization'];
  if (!header?.startsWith('Bearer ')) return res.status(401).json({ success:false, message:'مطلوب تسجيل الدخول' });
  try {
    const payload = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET);
    const user = db.prepare('SELECT id, email, role, is_active FROM users WHERE id = ?').get(payload.id);
    if (!user || !user.is_active) return res.status(401).json({ success:false, message:'الحساب غير موجود أو معطّل' });
    req.user = user;
    next();
  } catch (_) { res.status(401).json({ success:false, message:'جلسة منتهية' }); }
};

const requireAdmin = (req, res, next) => {
  if (req.user?.role !== 'admin') return res.status(403).json({ success:false, message:'للمدير فقط' });
  next();
};

module.exports = { authenticate, requireAdmin };
