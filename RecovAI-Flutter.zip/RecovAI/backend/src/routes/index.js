// src/routes/index.js
const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const db      = require('../config/database');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { generateRecoveryPlan } = require('../services/claudeService');

const sign = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
const sanitize = u => { const { password, ...s } = u; return s; };
const safe = (s, fb=null) => { try { return s ? JSON.parse(s) : fb; } catch { return fb; } };
const adm  = [authenticate, requireAdmin];

router.get('/health', (req, res) => res.json({ status: 'ok', time: new Date() }));

// ══ AUTH ══════════════════════════════════════════════════════════════════════
router.post('/auth/register', (req, res, next) => {
  try {
    const { firstName, lastName, email, password, age, weight, height, gender, activityLevel, sport } = req.body;
    if (!firstName||!email||!password) return res.status(400).json({ success:false, message:'بيانات ناقصة' });
    if (password.length < 6) return res.status(400).json({ success:false, message:'كلمة المرور قصيرة' });
    if (db.prepare('SELECT id FROM users WHERE email=?').get(email.toLowerCase())) {
      return res.status(409).json({ success:false, message:'البريد مستخدم مسبقاً' });
    }
    const hash = bcrypt.hashSync(password, 12);
    const r = db.prepare(`INSERT INTO users(first_name,last_name,email,password,age,weight,height,gender,activity_level,sport) VALUES(?,?,?,?,?,?,?,?,?,?)`)
      .run(firstName, lastName||'', email.toLowerCase(), hash, age||null, weight||null, height||null, gender||null, activityLevel||'متوسط', sport||null);
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid);
    res.status(201).json({ success:true, token: sign(user.id), user: sanitize(user) });
  } catch(err) { next(err); }
});

router.post('/auth/login', (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email||!password) return res.status(400).json({ success:false, message:'بيانات مطلوبة' });
    const user = db.prepare('SELECT * FROM users WHERE email=?').get(email.toLowerCase());
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ success:false, message:'البريد أو كلمة المرور غير صحيحة' });
    }
    if (!user.is_active) return res.status(403).json({ success:false, message:'الحساب معطّل' });
    res.json({ success:true, token: sign(user.id), user: sanitize(user) });
  } catch(err) { next(err); }
});

router.get('/auth/me', authenticate, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  res.json({ success:true, user: sanitize(user) });
});

router.post('/auth/forgot-password', (req, res) => res.json({ success:true, message:'إذا كان البريد مسجلاً ستصلك رسالة' }));

// ══ USERS ════════════════════════════════════════════════════════════════════
router.get('/users/me', authenticate, (req, res) => {
  res.json({ success:true, user: sanitize(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) });
});
router.patch('/users/me', authenticate, (req, res, next) => {
  try {
    const { firstName, lastName, photoUrl, age, weight, height, gender, activityLevel, sport } = req.body;
    db.prepare(`UPDATE users SET first_name=COALESCE(?,first_name),last_name=COALESCE(?,last_name),
      photo_url=COALESCE(?,photo_url),age=COALESCE(?,age),weight=COALESCE(?,weight),height=COALESCE(?,height),
      gender=COALESCE(?,gender),activity_level=COALESCE(?,activity_level),sport=COALESCE(?,sport),updated_at=datetime('now')
      WHERE id=?`).run(firstName,lastName,photoUrl,age,weight,height,gender,activityLevel,sport,req.user.id);
    res.json({ success:true, user: sanitize(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) });
  } catch(err) { next(err); }
});
router.patch('/users/me/password', authenticate, (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    if (!bcrypt.compareSync(currentPassword, user.password)) return res.status(401).json({ success:false, message:'كلمة المرور الحالية خاطئة' });
    db.prepare('UPDATE users SET password=? WHERE id=?').run(bcrypt.hashSync(newPassword, 12), req.user.id);
    res.json({ success:true, message:'تم التغيير' });
  } catch(err) { next(err); }
});

// ══ WORKOUTS ═════════════════════════════════════════════════════════════════
router.post('/workouts', authenticate, (req, res, next) => {
  try {
    const { sport, duration, intensity, timeOfDay, zones, notes } = req.body;
    if (!sport||!duration||!intensity||!zones?.length) return res.status(400).json({ success:false, message:'بيانات ناقصة' });
    const r = db.prepare(`INSERT INTO workouts(user_id,sport,duration,intensity,time_of_day,zones,notes) VALUES(?,?,?,?,?,?,?)`)
      .run(req.user.id, sport, Number(duration), intensity, timeOfDay||'مسائي', JSON.stringify(zones), notes||null);
    const w = db.prepare('SELECT * FROM workouts WHERE id=?').get(r.lastInsertRowid);
    res.status(201).json({ success:true, workout: { ...w, zones: safe(w.zones,[]) } });
  } catch(err) { next(err); }
});
router.get('/workouts', authenticate, (req, res) => {
  const ws = db.prepare('SELECT * FROM workouts WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.user.id)
    .map(w => ({ ...w, zones: safe(w.zones,[]) }));
  res.json({ success:true, data: ws });
});
router.delete('/workouts/:id', authenticate, (req, res) => {
  db.prepare('DELETE FROM workouts WHERE id=? AND user_id=?').run(req.params.id, req.user.id);
  res.json({ success:true });
});

// ══ RECOVERY PLANS — Claude AI ═══════════════════════════════════════════════
router.post('/recovery/generate', authenticate, async (req, res, next) => {
  try {
    const { sport, duration, intensity, zones, timeOfDay, workoutId } = req.body;
    if (!sport||!duration||!intensity||!zones?.length) return res.status(400).json({ success:false, message:'بيانات ناقصة' });
    const planData = await generateRecoveryPlan({ sport, duration: Number(duration), intensity, zones, timeOfDay: timeOfDay||'مسائي' });
    const r = db.prepare(`INSERT INTO recovery_plans(user_id,workout_id,recovery_score,summary,stretching,hydration,sleep,nutrition,massage,warnings,ai_generated)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
      .run(req.user.id, workoutId||null, planData.recoveryScore, planData.summary,
        JSON.stringify(planData.stretching), JSON.stringify(planData.hydration),
        JSON.stringify(planData.sleep), JSON.stringify(planData.nutrition),
        JSON.stringify(planData.massage||[]), JSON.stringify(planData.warnings||[]),
        planData._source==='claude-ai'?1:0);
    const source = planData._source; delete planData._source;
    res.status(201).json({ success:true, plan: { id: r.lastInsertRowid, ...planData, source, createdAt: new Date().toISOString() } });
  } catch(err) { next(err); }
});
router.get('/recovery/latest', authenticate, (req, res) => {
  const row = db.prepare('SELECT * FROM recovery_plans WHERE user_id=? ORDER BY created_at DESC LIMIT 1').get(req.user.id);
  if (!row) return res.json({ success:true, plan:null });
  res.json({ success:true, plan: {
    ...row,
    stretching: safe(row.stretching,{}), hydration: safe(row.hydration,{}),
    sleep: safe(row.sleep,{}), nutrition: safe(row.nutrition,{}),
    massage: safe(row.massage,[]), warnings: safe(row.warnings,[])
  }});
});
router.get('/recovery', authenticate, (req, res) => {
  const plans = db.prepare('SELECT * FROM recovery_plans WHERE user_id=? ORDER BY created_at DESC LIMIT 20').all(req.user.id)
    .map(row => ({ ...row, stretching: safe(row.stretching,{}), hydration: safe(row.hydration,{}),
      sleep: safe(row.sleep,{}), nutrition: safe(row.nutrition,{}), massage: safe(row.massage,[]), warnings: safe(row.warnings,[]) }));
  res.json({ success:true, data: plans });
});

// ══ EXERCISES (public read, admin write) ══════════════════════════════════════
router.get('/exercises', (req, res) => {
  const exs = db.prepare('SELECT * FROM exercises WHERE is_active=1 ORDER BY id').all()
    .map(e => ({ ...e, zones: safe(e.zones,[]) }));
  res.json({ success:true, data: exs });
});
router.post('/admin/exercises', adm, (req, res, next) => {
  try {
    const { name, type, duration, intensity, zones, icon, description, videoUrl } = req.body;
    const r = db.prepare('INSERT INTO exercises(name,type,duration,intensity,zones,icon,description,video_url) VALUES(?,?,?,?,?,?,?,?)')
      .run(name, type||'إطالة', duration||null, intensity||'خفيف', JSON.stringify(zones||[]), icon||'🧘', description||null, videoUrl||null);
    res.status(201).json({ success:true, exercise: db.prepare('SELECT * FROM exercises WHERE id=?').get(r.lastInsertRowid) });
  } catch(err) { next(err); }
});
router.patch('/admin/exercises/:id', adm, (req, res, next) => {
  try {
    const { name, type, duration, intensity, zones, icon, description, isActive } = req.body;
    db.prepare(`UPDATE exercises SET name=COALESCE(?,name),type=COALESCE(?,type),duration=COALESCE(?,duration),
      intensity=COALESCE(?,intensity),zones=COALESCE(?,zones),icon=COALESCE(?,icon),description=COALESCE(?,description),
      is_active=COALESCE(?,is_active),updated_at=datetime('now') WHERE id=?`)
      .run(name,type,duration,intensity,zones?JSON.stringify(zones):null,icon,description,
        isActive!==undefined?(isActive?1:0):null, req.params.id);
    res.json({ success:true });
  } catch(err) { next(err); }
});
router.delete('/admin/exercises/:id', adm, (req, res) => {
  db.prepare('UPDATE exercises SET is_active=0 WHERE id=?').run(req.params.id);
  res.json({ success:true });
});

// ══ RECIPES (public read, admin write) ═══════════════════════════════════════
router.get('/recipes', (req, res) => {
  const rs = db.prepare('SELECT * FROM nutrition_recipes WHERE is_active=1 ORDER BY views DESC').all()
    .map(r => ({ ...r, ingredients: safe(r.ingredients,[]), steps: safe(r.steps,[]) }));
  res.json({ success:true, data: rs });
});
router.post('/admin/recipes', adm, (req, res, next) => {
  try {
    const { name, type, prepTime, ingredients, steps, benefit, icon } = req.body;
    const r = db.prepare('INSERT INTO nutrition_recipes(name,type,prep_time,ingredients,steps,benefit,icon) VALUES(?,?,?,?,?,?,?)')
      .run(name, type||'بعد التمرين', prepTime||null, JSON.stringify(ingredients||[]), JSON.stringify(steps||[]), benefit||null, icon||'🥗');
    res.status(201).json({ success:true, recipe: db.prepare('SELECT * FROM nutrition_recipes WHERE id=?').get(r.lastInsertRowid) });
  } catch(err) { next(err); }
});
router.patch('/admin/recipes/:id', adm, (req, res) => {
  db.prepare('UPDATE nutrition_recipes SET name=COALESCE(?,name),benefit=COALESCE(?,benefit) WHERE id=?')
    .run(req.body.name||null, req.body.benefit||null, req.params.id);
  res.json({ success:true });
});

// ══ NOTIFICATIONS ════════════════════════════════════════════════════════════
router.get('/notifications', authenticate, (req, res) => {
  const notifs = db.prepare('SELECT * FROM notifications WHERE (user_id=? OR target="all") ORDER BY created_at DESC LIMIT 30').all(req.user.id);
  res.json({ success:true, data: notifs });
});
router.patch('/notifications/read-all', authenticate, (req, res) => {
  db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=? OR target="all"').run(req.user.id);
  res.json({ success:true });
});
router.post('/admin/notifications', adm, (req, res, next) => {
  try {
    const { title, body, type, target, userId } = req.body;
    db.prepare('INSERT INTO notifications(user_id,title,body,type,target) VALUES(?,?,?,?,?)')
      .run(target==='user'?userId:null, title, body, type||'general', target||'all');
    res.status(201).json({ success:true });
  } catch(err) { next(err); }
});

// ══ ADMIN ════════════════════════════════════════════════════════════════════
router.get('/admin/dashboard', adm, (req, res) => {
  const totalUsers  = db.prepare("SELECT COUNT(*) as c FROM users WHERE role!='admin'").get().c;
  const activeUsers = db.prepare("SELECT COUNT(*) as c FROM users WHERE role!='admin' AND is_active=1").get().c;
  const totalWOs    = db.prepare('SELECT COUNT(*) as c FROM workouts').get().c;
  const totalPlans  = db.prepare('SELECT COUNT(*) as c FROM recovery_plans').get().c;
  const topSports   = db.prepare('SELECT sport, COUNT(*) as count FROM workouts GROUP BY sport ORDER BY count DESC LIMIT 5').all();
  const planDist    = db.prepare("SELECT plan, COUNT(*) as count FROM users WHERE role!='admin' GROUP BY plan").all();
  res.json({ success:true, stats: {
    users: { total: totalUsers, active: activeUsers },
    workouts: { total: totalWOs }, plans: { total: totalPlans },
    topSports, planDistribution: planDist
  }});
});
router.get('/admin/users', adm, (req, res) => {
  const { search } = req.query;
  let sql = "SELECT * FROM users WHERE role!='admin'";
  const params = [];
  if (search) { sql += ' AND (first_name LIKE ? OR email LIKE ?)'; params.push(`%${search}%`,`%${search}%`); }
  sql += ' ORDER BY created_at DESC LIMIT 50';
  res.json({ success:true, data: db.prepare(sql).all(...params).map(sanitize) });
});
router.patch('/admin/users/:id/status', adm, (req, res) => {
  const u = db.prepare('SELECT is_active FROM users WHERE id=?').get(req.params.id);
  db.prepare('UPDATE users SET is_active=? WHERE id=?').run(u.is_active?0:1, req.params.id);
  res.json({ success:true });
});
router.patch('/admin/users/:id/plan', adm, (req, res) => {
  db.prepare('UPDATE users SET plan=? WHERE id=?').run(req.body.plan, req.params.id);
  res.json({ success:true });
});
router.delete('/admin/users/:id', adm, (req, res) => {
  db.prepare("DELETE FROM users WHERE id=? AND role!='admin'").run(req.params.id);
  res.json({ success:true });
});

module.exports = router;
