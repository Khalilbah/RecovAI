// src/services/claudeService.js
const db = require('../config/database');
require('dotenv').config();

const API   = 'https://api.anthropic.com/v1/messages';
const MODEL = process.env.CLAUDE_MODEL || 'claude-sonnet-4-20250514';

function getLibrary() {
  const exercises = db.prepare('SELECT * FROM exercises WHERE is_active=1').all()
    .map(e => ({ ...e, zones: JSON.parse(e.zones || '[]') }));
  const recipes = db.prepare('SELECT * FROM nutrition_recipes WHERE is_active=1').all()
    .map(r => ({ ...r, ingredients: JSON.parse(r.ingredients || '[]'), steps: JSON.parse(r.steps || '[]') }));
  const tips = db.prepare('SELECT * FROM sleep_hydration_tips WHERE is_active=1').all();
  return { exercises, recipes, sleepTips: tips.filter(t=>t.type==='sleep'), hydrationTips: tips.filter(t=>t.type==='hydration') };
}

async function generateRecoveryPlan(workoutData) {
  const library = getLibrary();
  if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY === 'sk-ant-your-key-here') {
    return rulesBased(workoutData, library);
  }
  try {
    const fetch = (await import('node-fetch')).default;
    const { sport, duration, intensity, zones, timeOfDay } = workoutData;

    const exList = library.exercises.map(e =>
      `ID:${e.id}|${e.icon} ${e.name}(${e.type})|المدة:${e.duration}|المناطق:${e.zones.join(',')}|الشرح:${e.description}`
    ).join('\n');
    const recList = library.recipes.map(r =>
      `ID:${r.id}|${r.icon} ${r.name}(${r.type})|المكونات:${r.ingredients.join(',')}|الفائدة:${r.benefit}`
    ).join('\n');
    const massageList = library.exercises.filter(e=>e.type==='تدليك').map(e=>
      `ID:${e.id}|${e.icon} ${e.name}|${e.description}`).join('\n');

    const prompt = `أنت مدرب استشفاء رياضي. اختر من المكتبة أدناه ولا تخترع عناصر جديدة.

══ التمرين ══
الرياضة: ${sport} | المدة: ${duration} دقيقة | الشدة: ${intensity} | مناطق التعب: ${zones.join('، ')} | الوقت: ${timeOfDay}

══ مكتبة التمارين (الإطالة) ══
${exList}

══ مكتبة الوصفات ══
${recList}

══ مكتبة التدليك ══
${massageList || 'لا يوجد'}

══ نصائح النوم ══
${library.sleepTips.map(t=>t.body).join(' | ')}

أرجع JSON فقط بلا markdown بالشكل:
{
  "recoveryScore": 75,
  "summary": "ملخص مفصل للخطة",
  "stretching": {
    "duration": "20 دقيقة",
    "exercises": [{"id":1,"name":"اسم","duration":"2 دقيقة","icon":"🧘","description":"شرح مفصل لهذا التمرين بعد ${sport} بشدة ${intensity}"}]
  },
  "hydration": {"amount":"3 لتر","schedule":"جدول","tip":"نصيحة"},
  "sleep": {"hours":"8 ساعات","bedtime":"10:30 م","tips":["نصيحة1","نصيحة2"]},
  "nutrition": {"meals":[{"id":1,"name":"اسم","timing":"وقت","ingredients":["م1"],"benefit":"فائدة محددة","icon":"🥗"}]},
  "massage": [{"name":"اسم","icon":"💆","duration":"10 دقائق","desc":"طريقة التدليك لمنطقة ${zones.join('،')} بعد ${sport}"}],
  "warnings": []
}`;

    const res = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: MODEL, max_tokens: 2000, messages: [{ role: 'user', content: prompt }] })
    });
    if (!res.ok) return rulesBased(workoutData, library);
    const data = await res.json();
    const txt  = data.content?.map(b => b.text || '').join('') || '';
    const plan = JSON.parse(txt.replace(/```json|```/g, '').trim());
    plan._source = 'claude-ai';
    return plan;
  } catch (err) {
    console.error('Claude error:', err.message);
    return rulesBased(workoutData, library);
  }
}

function rulesBased(workoutData, library) {
  const { sport, intensity, zones, duration, timeOfDay } = workoutData;
  const scoreMap = { 'خفيف': 88, 'متوسط': 74, 'عالي': 58 };
  const exs = library.exercises
    .filter(e => e.type === 'إطالة' && zones.some(z => e.zones.includes(z)))
    .slice(0, 4).map(e => ({ id: e.id, name: e.name, duration: e.duration, icon: e.icon || '🧘', description: e.description }));
  const meal = library.recipes.find(r => r.type === 'بعد التمرين');
  const massage = library.exercises.filter(e => e.type === 'تدليك').slice(0, 2)
    .map(e => ({ name: e.name, icon: e.icon, duration: e.duration, desc: e.description }));
  return {
    recoveryScore: scoreMap[intensity] || 70,
    summary: `خطة استشفاء لـ ${sport} بشدة ${intensity} لمدة ${duration} دقيقة مع التركيز على ${zones.join(' و')}.`,
    stretching: { duration: '20 دقيقة', exercises: exs },
    hydration:  { amount: intensity==='عالي'?'3.5 لتر':'3 لتر', schedule: '500مل فوراً ثم 250مل كل ساعة', tip: 'أضف الإلكتروليتات' },
    sleep: { hours: intensity==='عالي'?'9 ساعات':'8 ساعات', bedtime: '10:30 م', tips: ['بيئة باردة', 'ابتعد عن الشاشات'] },
    nutrition: { meals: meal ? [{ id: meal.id, name: meal.name, timing: 'بعد التمرين', ingredients: meal.ingredients, benefit: meal.benefit, icon: meal.icon }] : [] },
    massage: massage.length ? massage : [{ name: 'تدليك عام', icon: '💆', duration: '10 دقائق', desc: `دلّك مناطق ${zones.join(' و')}` }],
    warnings: intensity === 'عالي' ? ['تعافٍ كامل: 48-72 ساعة'] : [],
    _source: 'rules-based',
  };
}

module.exports = { generateRecoveryPlan };
