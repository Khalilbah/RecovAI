// lib/core/constants/app_constants.dart

class AppConstants {
  AppConstants._();

  // ─── API ──────────────────────────────────────────────────────────────────
  // Android Emulator → 10.0.2.2  |  iOS Sim → localhost  |  Real device → your-ip
  // Production → https://your-server.com
  static const String apiBase = 'http://10.0.2.2:3000/api';
  static const Duration apiTimeout = Duration(seconds: 30);

  // ─── Storage Keys ─────────────────────────────────────────────────────────
  static const String tokenKey = 'recovai_token';

  // ─── Sports ───────────────────────────────────────────────────────────────
  static const List<Map<String, String>> sports = [
    {'name': 'جيم',       'emoji': '🏋️'},
    {'name': 'جري',       'emoji': '🏃'},
    {'name': 'سباحة',     'emoji': '🏊'},
    {'name': 'دراجة',     'emoji': '🚴'},
    {'name': 'كرة قدم',   'emoji': '⚽'},
    {'name': 'تنس',       'emoji': '🎾'},
    {'name': 'ملاكمة',    'emoji': '🥊'},
    {'name': 'يوغا',      'emoji': '🧘'},
    {'name': 'كروس فيت',  'emoji': '💪'},
    {'name': 'ركبي',      'emoji': '🏉'},
  ];

  // ─── Intensity ────────────────────────────────────────────────────────────
  static const List<Map<String, String>> intensities = [
    {'name': 'خفيف',   'emoji': '😊'},
    {'name': 'متوسط',  'emoji': '😤'},
    {'name': 'عالي',   'emoji': '🔥'},
  ];

  // ─── Body Zones ───────────────────────────────────────────────────────────
  static const List<Map<String, String>> bodyZones = [
    {'name': 'أرجل',      'emoji': '🦵'},
    {'name': 'ظهر',       'emoji': '🔙'},
    {'name': 'أكتاف',     'emoji': '💪'},
    {'name': 'صدر',       'emoji': '🫀'},
    {'name': 'ذراعين',    'emoji': '💪'},
    {'name': 'بطن',       'emoji': '🔵'},
    {'name': 'جسم كامل',  'emoji': '🌐'},
  ];

  // ─── Time of Day ──────────────────────────────────────────────────────────
  static const List<Map<String, String>> timesOfDay = [
    {'name': 'صباحي',  'emoji': '🌅'},
    {'name': 'مسائي',  'emoji': '🌆'},
    {'name': 'ليلي',   'emoji': '🌙'},
  ];

  // ─── Activity Levels ──────────────────────────────────────────────────────
  static const List<Map<String, String>> activityLevels = [
    {'name': 'مبتدئ',  'desc': '1-2 مرة أسبوعياً'},
    {'name': 'متوسط',  'desc': '3-4 مرات أسبوعياً'},
    {'name': 'متقدم',  'desc': '5+ مرات أسبوعياً'},
  ];

  // ─── Plans ────────────────────────────────────────────────────────────────
  static const List<Map<String, dynamic>> subscriptionPlans = [
    {'id':'free',    'name':'مجانية', 'price':0,  'color':0xFF00BFB3},
    {'id':'starter', 'name':'ستارتر','price':19,  'color':0xFF16A85A},
    {'id':'pro',     'name':'برو',   'price':39,  'color':0xFFC8F135, 'popular':true},
    {'id':'premium', 'name':'بريميوم','price':79, 'color':0xFFF5A623},
  ];

  // ─── Gen Steps (AI loading messages) ─────────────────────────────────────
  static const List<String> genSteps = [
    'يحلل نوع التمرين...',
    'يفحص مناطق التعب...',
    'يُعدّ تمارين الإطالة...',
    'يصمم خطة التغذية...',
    'يحسب كمية الترطيب...',
    'جاري إنهاء الخطة...',
  ];
}
