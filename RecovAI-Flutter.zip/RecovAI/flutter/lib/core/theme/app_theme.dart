// lib/core/theme/app_theme.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppColors {
  AppColors._();
  static const Color lime      = Color(0xFFC8F135);
  static const Color limeDeep  = Color(0xFFA8D410);
  static const Color limeBg    = Color(0x26C8F135);
  static const Color bg        = Color(0xFFF2EFE9);
  static const Color white     = Color(0xFFFFFFFF);
  static const Color inner     = Color(0xFFF7F5F0);
  static const Color border    = Color(0x12000000);
  static const Color text      = Color(0xFF1A1A1A);
  static const Color textSec   = Color(0xFF6E6860);
  static const Color textMuted = Color(0xFFB0A898);
  static const Color darkBg    = Color(0xFF12141F);
  static const Color darkCard  = Color(0xFF1E2030);
  static const Color darkInner = Color(0xFF262840);
  static const Color darkText  = Color(0xFFE8E4DC);
  static const Color darkSec   = Color(0xFF8A8478);
  static const Color darkBorder= Color(0x12FFFFFF);
  static const Color red       = Color(0xFFFF5C5C);
  static const Color redBg     = Color(0x1AFF5C5C);
  static const Color green     = Color(0xFF16A85A);
  static const Color greenBg   = Color(0x1F16A85A);
  static const Color amber     = Color(0xFFF5A623);
  static const Color amberBg   = Color(0x1AF5A623);
  static const Color teal      = Color(0xFF00BFB3);
  static const Color tealBg    = Color(0x1A00BFB3);
  static const Color overlay   = Color(0x9E0A0A14);
}

class AppColorsExtension extends ThemeExtension<AppColorsExtension> {
  final bool isDark;
  const AppColorsExtension({required this.isDark});
  Color get cardBg        => isDark ? AppColors.darkCard   : AppColors.white;
  Color get innerBg       => isDark ? AppColors.darkInner  : AppColors.inner;
  Color get scaffoldBg    => isDark ? AppColors.darkBg     : AppColors.bg;
  Color get textPrimary   => isDark ? AppColors.darkText   : AppColors.text;
  Color get textSecondary => isDark ? AppColors.darkSec    : AppColors.textSec;
  Color get borderColor   => isDark ? AppColors.darkBorder : AppColors.border;
  @override AppColorsExtension copyWith({bool? isDark}) => AppColorsExtension(isDark: isDark ?? this.isDark);
  @override AppColorsExtension lerp(AppColorsExtension? other, double t) => this;
}

class AppTheme {
  AppTheme._();
  static ThemeData light() => _build(false);
  static ThemeData dark()  => _build(true);
  static ThemeData _build(bool dk) {
    final base   = dk ? AppColors.darkText : AppColors.text;
    final subtle = dk ? AppColors.darkSec  : AppColors.textSec;
    return ThemeData(
      useMaterial3: true,
      brightness: dk ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: dk ? AppColors.darkBg : AppColors.bg,
      fontFamily: 'Manrope',
      colorScheme: ColorScheme(
        brightness: dk ? Brightness.dark : Brightness.light,
        primary: AppColors.lime, onPrimary: AppColors.text,
        secondary: AppColors.teal, onSecondary: AppColors.white,
        error: AppColors.red, onError: AppColors.white,
        surface: dk ? AppColors.darkCard : AppColors.white, onSurface: base,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: dk ? AppColors.darkBg : AppColors.bg,
        foregroundColor: base, elevation: 0, centerTitle: false,
        systemOverlayStyle: dk ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
        titleTextStyle: TextStyle(fontFamily:'Manrope', fontSize:18, fontWeight:FontWeight.w800, color:base),
      ),
      tabBarTheme: const TabBarThemeData(
        indicatorColor: AppColors.lime,
        labelColor: AppColors.lime,
        unselectedLabelColor: AppColors.textMuted,
        labelStyle: TextStyle(fontFamily:'Manrope', fontWeight:FontWeight.w700, fontSize:14),
        unselectedLabelStyle: TextStyle(fontFamily:'Manrope', fontWeight:FontWeight.w600, fontSize:13),
      ),
      sliderTheme: const SliderThemeData(
        activeTrackColor: AppColors.lime, inactiveTrackColor: AppColors.limeBg,
        thumbColor: AppColors.lime, overlayColor: AppColors.limeBg, trackHeight: 4,
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: InputBorder.none,
        hintStyle: TextStyle(color: AppColors.textMuted, fontFamily: 'Manrope'),
      ),
      textTheme: TextTheme(
        displayLarge:  TextStyle(fontFamily:'Manrope', fontSize:32, fontWeight:FontWeight.w900, color:base),
        headlineLarge: TextStyle(fontFamily:'Manrope', fontSize:26, fontWeight:FontWeight.w900, color:base),
        headlineMedium:TextStyle(fontFamily:'Manrope', fontSize:22, fontWeight:FontWeight.w800, color:base),
        titleLarge:    TextStyle(fontFamily:'Manrope', fontSize:18, fontWeight:FontWeight.w800, color:base),
        titleMedium:   TextStyle(fontFamily:'Manrope', fontSize:16, fontWeight:FontWeight.w700, color:base),
        titleSmall:    TextStyle(fontFamily:'Manrope', fontSize:14, fontWeight:FontWeight.w700, color:base),
        bodyLarge:     TextStyle(fontFamily:'Manrope', fontSize:15, fontWeight:FontWeight.w500, color:base, height:1.6),
        bodyMedium:    TextStyle(fontFamily:'Manrope', fontSize:13, fontWeight:FontWeight.w500, color:subtle, height:1.5),
        labelLarge:    TextStyle(fontFamily:'Manrope', fontSize:12, fontWeight:FontWeight.w700, color:subtle, letterSpacing:1.5),
        labelSmall:    TextStyle(fontFamily:'Manrope', fontSize:10, fontWeight:FontWeight.w700, color:AppColors.textMuted, letterSpacing:1.5),
      ),
      extensions: [AppColorsExtension(isDark: dk)],
    );
  }
}
