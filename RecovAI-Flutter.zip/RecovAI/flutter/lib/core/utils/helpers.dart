// lib/core/utils/helpers.dart
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

String sportEmoji(String sport) {
  const m = {'جيم':'🏋️','جري':'🏃','سباحة':'🏊','دراجة':'🚴','كرة قدم':'⚽','تنس':'🎾','ملاكمة':'🥊','يوغا':'🧘','كروس فيت':'💪','ركبي':'🏉'};
  return m[sport] ?? '⚡';
}

Color intensityColor(String intensity) {
  switch (intensity) {
    case 'عالي':  return AppColors.red;
    case 'متوسط': return AppColors.amber;
    default:      return AppColors.green;
  }
}

String intensityEmoji(String intensity) {
  switch (intensity) {
    case 'عالي':  return '🔥';
    case 'متوسط': return '😤';
    default:      return '😊';
  }
}

String formatDuration(int minutes) {
  if (minutes < 60) return '$minutes دقيقة';
  final h = minutes ~/ 60;
  final m = minutes % 60;
  return m == 0 ? '$h ساعة' : '$h س $m د';
}

String bmiCategory(double bmi) {
  if (bmi < 18.5) return 'نقص وزن';
  if (bmi < 25)   return 'وزن مثالي ✅';
  if (bmi < 30)   return 'وزن زائد ⚠️';
  return 'سمنة 🔴';
}

Color bmiColor(double bmi) {
  if (bmi < 18.5) return AppColors.amber;
  if (bmi < 25)   return AppColors.green;
  if (bmi < 30)   return AppColors.amber;
  return AppColors.red;
}
