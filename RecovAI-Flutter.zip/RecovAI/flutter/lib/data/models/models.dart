// lib/data/models/models.dart
// جميع موديلات البيانات للتطبيق

class UserModel {
  final int id;
  final String firstName;
  final String lastName;
  final String email;
  final String role;
  final int? age;
  final double? weight;
  final double? height;
  final String? gender;
  final String? activityLevel;
  final String? sport;
  final String? photoUrl;
  final String plan;
  final bool isActive;

  const UserModel({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.role,
    this.age,
    this.weight,
    this.height,
    this.gender,
    this.activityLevel,
    this.sport,
    this.photoUrl,
    this.plan = 'مجانية',
    this.isActive = true,
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
    id:            j['id'] ?? 0,
    firstName:     j['first_name'] ?? j['firstName'] ?? '',
    lastName:      j['last_name']  ?? j['lastName']  ?? '',
    email:         j['email'] ?? '',
    role:          j['role']  ?? 'user',
    age:           j['age'],
    weight:        (j['weight'] as num?)?.toDouble(),
    height:        (j['height'] as num?)?.toDouble(),
    gender:        j['gender'],
    activityLevel: j['activity_level'] ?? j['activityLevel'],
    sport:         j['sport'],
    photoUrl:      j['photo_url'] ?? j['photoUrl'],
    plan:          j['plan'] ?? 'مجانية',
    isActive:      j['is_active'] == 1 || j['is_active'] == true,
  );

  String get fullName => '$firstName $lastName';
  bool   get isAdmin  => role == 'admin';

  double? get bmi => (weight != null && height != null && height! > 0)
      ? weight! / ((height! / 100) * (height! / 100))
      : null;
}

// ─── Workout ───────────────────────────────────────────────────────────────────
class WorkoutModel {
  final int?   id;
  final String sport;
  final int    duration;
  final String intensity;
  final String timeOfDay;
  final List<String> zones;
  final String? notes;
  final String? workoutDate;
  final String? createdAt;

  const WorkoutModel({
    this.id,
    required this.sport,
    required this.duration,
    required this.intensity,
    this.timeOfDay = 'مسائي',
    this.zones = const [],
    this.notes,
    this.workoutDate,
    this.createdAt,
  });

  factory WorkoutModel.fromJson(Map<String, dynamic> j) => WorkoutModel(
    id:          j['id'],
    sport:       j['sport'] ?? '',
    duration:    j['duration'] ?? 0,
    intensity:   j['intensity'] ?? 'متوسط',
    timeOfDay:   j['time_of_day'] ?? j['timeOfDay'] ?? 'مسائي',
    zones:       List<String>.from(j['zones'] ?? []),
    notes:       j['notes'],
    workoutDate: j['workout_date'] ?? j['workoutDate'],
    createdAt:   j['created_at']  ?? j['createdAt'],
  );

  Map<String, dynamic> toJson() => {
    'sport':     sport,
    'duration':  duration,
    'intensity': intensity,
    'timeOfDay': timeOfDay,
    'zones':     zones,
    if (notes != null) 'notes': notes,
  };

  Color get intensityColor {
    switch (intensity) {
      case 'عالي':   return const Color(0xFFFF5C5C);
      case 'متوسط':  return const Color(0xFFF5A623);
      default:       return const Color(0xFF16A85A);
    }
  }
}

// ─── Recovery Plan ─────────────────────────────────────────────────────────────
class RecoveryPlanModel {
  final int?   id;
  final int    recoveryScore;
  final String summary;
  final StretchingData stretching;
  final HydrationData  hydration;
  final SleepData      sleep;
  final NutritionData  nutrition;
  final List<MassageItem> massage;
  final List<String>   warnings;
  final String? source;
  final String? createdAt;

  const RecoveryPlanModel({
    this.id,
    required this.recoveryScore,
    required this.summary,
    required this.stretching,
    required this.hydration,
    required this.sleep,
    required this.nutrition,
    this.massage = const [],
    this.warnings = const [],
    this.source,
    this.createdAt,
  });

  factory RecoveryPlanModel.fromJson(Map<String, dynamic> j) {
    // Handle both nested objects and JSON strings
    final stretchRaw = j['stretching'];
    final hydRaw     = j['hydration'];
    final sleepRaw   = j['sleep'];
    final nutRaw     = j['nutrition'];
    final massageRaw = j['massage'];

    return RecoveryPlanModel(
      id:            j['id'],
      recoveryScore: j['recovery_score'] ?? j['recoveryScore'] ?? 70,
      summary:       j['summary'] ?? '',
      stretching:    StretchingData.fromJson(stretchRaw is Map ? stretchRaw : {}),
      hydration:     HydrationData.fromJson(hydRaw is Map ? hydRaw : {}),
      sleep:         SleepData.fromJson(sleepRaw is Map ? sleepRaw : {}),
      nutrition:     NutritionData.fromJson(nutRaw is Map ? nutRaw : {}),
      massage:       massageRaw is List
          ? massageRaw.map((m) => MassageItem.fromJson(m)).toList()
          : [],
      warnings:      List<String>.from(j['warnings'] ?? []),
      source:        j['source'],
      createdAt:     j['created_at'] ?? j['createdAt'],
    );
  }

  Color get scoreColor {
    if (recoveryScore >= 80) return const Color(0xFF16A85A);
    if (recoveryScore >= 60) return const Color(0xFFF5A623);
    return const Color(0xFFFF5C5C);
  }
}

class StretchingData {
  final String duration;
  final List<ExerciseItem> exercises;
  const StretchingData({required this.duration, required this.exercises});
  factory StretchingData.fromJson(Map<String, dynamic> j) => StretchingData(
    duration:  j['duration'] ?? '15 دقيقة',
    exercises: (j['exercises'] as List? ?? []).map((e) => ExerciseItem.fromJson(e)).toList(),
  );
}

class ExerciseItem {
  final int?   id;
  final String name;
  final String duration;
  final String icon;
  final String description;
  const ExerciseItem({this.id, required this.name, required this.duration, required this.icon, required this.description});
  factory ExerciseItem.fromJson(Map<String, dynamic> j) => ExerciseItem(
    id:          j['id'],
    name:        j['name'] ?? '',
    duration:    j['duration'] ?? '',
    icon:        j['icon'] ?? '🧘',
    description: j['description'] ?? '',
  );
}

class HydrationData {
  final String amount;
  final String schedule;
  final String tip;
  const HydrationData({required this.amount, required this.schedule, required this.tip});
  factory HydrationData.fromJson(Map<String, dynamic> j) => HydrationData(
    amount:   j['amount'] ?? '3 لتر',
    schedule: j['schedule'] ?? '',
    tip:      j['tip'] ?? '',
  );
}

class SleepData {
  final String hours;
  final String bedtime;
  final List<String> tips;
  const SleepData({required this.hours, required this.bedtime, required this.tips});
  factory SleepData.fromJson(Map<String, dynamic> j) => SleepData(
    hours:   j['hours'] ?? '8 ساعات',
    bedtime: j['bedtime'] ?? '10:30 م',
    tips:    List<String>.from(j['tips'] ?? []),
  );
}

class NutritionData {
  final List<MealItem> meals;
  const NutritionData({required this.meals});
  factory NutritionData.fromJson(Map<String, dynamic> j) => NutritionData(
    meals: (j['meals'] as List? ?? []).map((m) => MealItem.fromJson(m)).toList(),
  );
}

class MealItem {
  final int?   id;
  final String name;
  final String timing;
  final List<String> ingredients;
  final String benefit;
  final String icon;
  const MealItem({this.id, required this.name, required this.timing, required this.ingredients, required this.benefit, required this.icon});
  factory MealItem.fromJson(Map<String, dynamic> j) => MealItem(
    id:          j['id'],
    name:        j['name'] ?? '',
    timing:      j['timing'] ?? '',
    ingredients: List<String>.from(j['ingredients'] ?? []),
    benefit:     j['benefit'] ?? '',
    icon:        j['icon'] ?? '🥗',
  );
}

class MassageItem {
  final String name;
  final String icon;
  final String duration;
  final String desc;
  const MassageItem({required this.name, required this.icon, required this.duration, required this.desc});
  factory MassageItem.fromJson(Map<String, dynamic> j) => MassageItem(
    name:     j['name'] ?? '',
    icon:     j['icon'] ?? '💆',
    duration: j['duration'] ?? '',
    desc:     j['desc'] ?? '',
  );
}

// ─── Fix missing Color import ───────────────────────────────────────────────
import 'package:flutter/material.dart';
