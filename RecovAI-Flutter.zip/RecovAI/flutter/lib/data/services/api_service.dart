// lib/data/services/api_service.dart
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../models/models.dart';

class ApiService {
  // ─── تغيير هذا العنوان عند النشر ───────────────────────────────────────────
  static const String baseUrl = 'http://10.0.2.2:3000/api';
  // Android Emulator: 10.0.2.2  |  iOS Simulator: localhost  |  Production: https://your-server.com/api

  static const _storage = FlutterSecureStorage();
  static const _tokenKey = 'recovai_token';

  // ─── Token ─────────────────────────────────────────────────────────────────
  static Future<String?> getToken()            => _storage.read(key: _tokenKey);
  static Future<void>    setToken(String token) => _storage.write(key: _tokenKey, value: token);
  static Future<void>    clearToken()           => _storage.delete(key: _tokenKey);

  // ─── Base Request ──────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> _req(
    String method, String path, {Map<String, dynamic>? body,
  }) async {
    final token = await getToken();
    final headers = {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
    final uri = Uri.parse('$baseUrl$path');
    late http.Response res;

    switch (method) {
      case 'GET':    res = await http.get(uri, headers: headers); break;
      case 'POST':   res = await http.post(uri, headers: headers, body: jsonEncode(body ?? {})); break;
      case 'PATCH':  res = await http.patch(uri, headers: headers, body: jsonEncode(body ?? {})); break;
      case 'DELETE': res = await http.delete(uri, headers: headers); break;
      default: throw Exception('Unknown method');
    }

    final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    if (res.statusCode >= 400) {
      throw ApiException(data['message'] ?? 'خطأ في الخادم', res.statusCode);
    }
    return data;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // AUTH
  // ══════════════════════════════════════════════════════════════════════════
  static Future<AuthResult> register({
    required String firstName, required String lastName,
    required String email,     required String password,
    int? age, double? weight, double? height,
    String? gender, String? activityLevel, String? sport,
  }) async {
    final data = await _req('POST', '/auth/register', body: {
      'firstName': firstName, 'lastName': lastName,
      'email': email,         'password': password,
      if (age    != null) 'age':    age,
      if (weight != null) 'weight': weight,
      if (height != null) 'height': height,
      if (gender        != null) 'gender':        gender,
      if (activityLevel != null) 'activityLevel': activityLevel,
      if (sport         != null) 'sport':         sport,
    });
    await setToken(data['token']);
    return AuthResult(token: data['token'], user: UserModel.fromJson(data['user']));
  }

  static Future<AuthResult> login({required String email, required String password}) async {
    final data = await _req('POST', '/auth/login', body: {'email': email, 'password': password});
    await setToken(data['token']);
    return AuthResult(token: data['token'], user: UserModel.fromJson(data['user']));
  }

  static Future<UserModel> getMe() async {
    final data = await _req('GET', '/auth/me');
    return UserModel.fromJson(data['user']);
  }

  static Future<void> forgotPassword(String email) async =>
    _req('POST', '/auth/forgot-password', body: {'email': email});

  // ══════════════════════════════════════════════════════════════════════════
  // WORKOUTS
  // ══════════════════════════════════════════════════════════════════════════
  static Future<WorkoutModel> createWorkout(WorkoutModel w) async {
    final data = await _req('POST', '/workouts', body: w.toJson());
    return WorkoutModel.fromJson(data['workout']);
  }

  static Future<List<WorkoutModel>> getWorkouts() async {
    final data = await _req('GET', '/workouts');
    return (data['data'] as List).map((w) => WorkoutModel.fromJson(w)).toList();
  }

  static Future<void> deleteWorkout(int id) async =>
    _req('DELETE', '/workouts/$id');

  // ══════════════════════════════════════════════════════════════════════════
  // RECOVERY PLANS — Claude AI
  // ══════════════════════════════════════════════════════════════════════════
  static Future<RecoveryPlanModel> generatePlan({
    required WorkoutModel workout, int? workoutId,
  }) async {
    final data = await _req('POST', '/recovery/generate', body: {
      ...workout.toJson(),
      if (workoutId != null) 'workoutId': workoutId,
    });
    return RecoveryPlanModel.fromJson(data['plan']);
  }

  static Future<RecoveryPlanModel?> getLatestPlan() async {
    final data = await _req('GET', '/recovery/latest');
    if (data['plan'] == null) return null;
    return RecoveryPlanModel.fromJson(data['plan']);
  }

  static Future<List<RecoveryPlanModel>> getMyPlans() async {
    final data = await _req('GET', '/recovery');
    return (data['data'] as List).map((p) => RecoveryPlanModel.fromJson(p)).toList();
  }

  // ══════════════════════════════════════════════════════════════════════════
  // USER PROFILE
  // ══════════════════════════════════════════════════════════════════════════
  static Future<UserModel> updateProfile({
    String? firstName, String? lastName, String? photoUrl,
    int? age, double? weight, double? height,
    String? gender, String? activityLevel, String? sport,
  }) async {
    final data = await _req('PATCH', '/users/me', body: {
      if (firstName     != null) 'firstName':     firstName,
      if (lastName      != null) 'lastName':      lastName,
      if (photoUrl      != null) 'photoUrl':      photoUrl,
      if (age           != null) 'age':           age,
      if (weight        != null) 'weight':        weight,
      if (height        != null) 'height':        height,
      if (gender        != null) 'gender':        gender,
      if (activityLevel != null) 'activityLevel': activityLevel,
      if (sport         != null) 'sport':         sport,
    });
    return UserModel.fromJson(data['user']);
  }

  static Future<void> changePassword({required String current, required String next}) async =>
    _req('PATCH', '/users/me/password', body: {'currentPassword': current, 'newPassword': next});

  // ══════════════════════════════════════════════════════════════════════════
  // ADMIN
  // ══════════════════════════════════════════════════════════════════════════
  static Future<Map<String, dynamic>> getDashboardStats() =>
    _req('GET', '/admin/dashboard');

  static Future<List<UserModel>> getAdminUsers({String? search}) async {
    final q = search != null ? '?search=$search' : '';
    final data = await _req('GET', '/admin/users$q');
    return (data['data'] as List).map((u) => UserModel.fromJson(u)).toList();
  }

  static Future<void> toggleUserStatus(int id) async =>
    _req('PATCH', '/admin/users/$id/status');

  static Future<void> deleteUser(int id) async =>
    _req('DELETE', '/admin/users/$id');

  static Future<void> updateUserPlan(int id, String plan) async =>
    _req('PATCH', '/admin/users/$id/plan', body: {'plan': plan});

  // ─── Exercises (Admin CRUD) ────────────────────────────────────────────────
  static Future<List<Map<String, dynamic>>> getExercises() async {
    final data = await _req('GET', '/exercises');
    return List<Map<String, dynamic>>.from(data['data']);
  }

  static Future<void> createExercise(Map<String, dynamic> body) =>
    _req('POST', '/admin/exercises', body: body);

  static Future<void> updateExercise(int id, Map<String, dynamic> body) =>
    _req('PATCH', '/admin/exercises/$id', body: body);

  static Future<void> deleteExercise(int id) =>
    _req('DELETE', '/admin/exercises/$id');

  // ─── Recipes (Admin CRUD) ─────────────────────────────────────────────────
  static Future<List<Map<String, dynamic>>> getRecipes() async {
    final data = await _req('GET', '/recipes');
    return List<Map<String, dynamic>>.from(data['data']);
  }

  static Future<void> createRecipe(Map<String, dynamic> body) =>
    _req('POST', '/admin/recipes', body: body);

  static Future<void> updateRecipe(int id, Map<String, dynamic> body) =>
    _req('PATCH', '/admin/recipes/$id', body: body);

  // ─── Notifications ────────────────────────────────────────────────────────
  static Future<List<Map<String, dynamic>>> getNotifications() async {
    final data = await _req('GET', '/notifications');
    return List<Map<String, dynamic>>.from(data['data']);
  }

  static Future<void> sendNotification({required String title, required String body, String target = 'all'}) =>
    _req('POST', '/admin/notifications', body: {'title': title, 'body': body, 'target': target});

  // ─── Health Check ─────────────────────────────────────────────────────────
  static Future<bool> checkHealth() async {
    try {
      final res = await http.get(Uri.parse(baseUrl.replaceAll('/api', '/api/health')))
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) { return false; }
  }
}

class AuthResult {
  final String    token;
  final UserModel user;
  const AuthResult({required this.token, required this.user});
}

class ApiException implements Exception {
  final String message;
  final int    statusCode;
  const ApiException(this.message, this.statusCode);
  @override String toString() => message;
}
