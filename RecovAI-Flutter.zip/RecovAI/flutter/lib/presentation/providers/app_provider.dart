// lib/presentation/providers/app_provider.dart
import 'package:flutter/material.dart';
import '../../data/models/models.dart';
import '../../data/services/api_service.dart';

class AppProvider extends ChangeNotifier {
  UserModel?         _user;
  RecoveryPlanModel? _currentPlan;
  WorkoutModel?      _lastWorkout;
  List<WorkoutModel> _workouts  = [];
  ThemeMode          _themeMode = ThemeMode.system;
  bool               _loading   = false;
  String?            _error;

  // ─── Getters ───────────────────────────────────────────────────────────────
  UserModel?         get user         => _user;
  RecoveryPlanModel? get currentPlan  => _currentPlan;
  WorkoutModel?      get lastWorkout  => _lastWorkout;
  List<WorkoutModel> get workouts     => _workouts;
  ThemeMode          get themeMode    => _themeMode;
  bool               get isLoading    => _loading;
  String?            get error        => _error;
  bool               get isLoggedIn   => _user != null;
  bool               get isAdmin      => _user?.isAdmin ?? false;

  void setTheme(ThemeMode m) { _themeMode = m; notifyListeners(); }

  // ─── Session Restore ───────────────────────────────────────────────────────
  Future<bool> restoreSession() async {
    final token = await ApiService.getToken();
    if (token == null) return false;
    try {
      _user = await ApiService.getMe();
      // جلب آخر خطة وتمارين
      _currentPlan = await ApiService.getLatestPlan();
      final wRes = await ApiService.getWorkouts();
      _workouts = wRes;
      notifyListeners();
      return true;
    } catch (_) {
      await ApiService.clearToken();
      return false;
    }
  }

  // ─── Auth ──────────────────────────────────────────────────────────────────
  Future<void> register({
    required String firstName, required String lastName,
    required String email,     required String password,
    int? age, double? weight, double? height,
    String? gender, String? activityLevel, String? sport,
  }) async {
    _setLoading(true);
    final res = await ApiService.register(
      firstName: firstName, lastName: lastName,
      email: email, password: password,
      age: age, weight: weight, height: height,
      gender: gender, activityLevel: activityLevel, sport: sport,
    );
    _user = res.user;
    _setLoading(false);
  }

  Future<void> login({required String email, required String password}) async {
    _setLoading(true);
    final res = await ApiService.login(email: email, password: password);
    _user = res.user;
    _setLoading(false);
  }

  Future<void> logout() async {
    await ApiService.clearToken();
    _user = null; _currentPlan = null; _lastWorkout = null; _workouts = [];
    notifyListeners();
  }

  // ─── Generate Plan ─────────────────────────────────────────────────────────
  Future<RecoveryPlanModel> generatePlan(WorkoutModel workout) async {
    _setLoading(true);
    // حفظ التمرين أولاً
    int? workoutId;
    try {
      final saved = await ApiService.createWorkout(workout);
      workoutId = saved.id;
      _workouts = [saved, ..._workouts];
    } catch (_) {}

    // إنشاء الخطة عبر Claude AI
    final plan = await ApiService.generatePlan(workout: workout, workoutId: workoutId);
    _currentPlan = plan;
    _lastWorkout = workout;
    _setLoading(false);
    return plan;
  }

  // ─── Update Profile ────────────────────────────────────────────────────────
  Future<void> updateProfile({String? firstName, String? lastName, String? photoUrl}) async {
    _setLoading(true);
    _user = await ApiService.updateProfile(
      firstName: firstName, lastName: lastName, photoUrl: photoUrl,
    );
    _setLoading(false);
  }

  void _setLoading(bool v) { _loading = v; _error = null; notifyListeners(); }
}
