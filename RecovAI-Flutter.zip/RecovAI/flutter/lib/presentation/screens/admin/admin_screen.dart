// lib/presentation/screens/admin/admin_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/models.dart';
import '../../../data/services/api_service.dart';
import '../../providers/app_provider.dart';
import '../../widgets/shared_widgets.dart';
import '../auth/welcome_screen.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  int    _tab = 0;
  Map<String, dynamic>? _stats;
  List<UserModel> _users = [];
  List<Map<String, dynamic>> _exercises = [];
  List<Map<String, dynamic>> _recipes   = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _loadAll(); }

  Future<void> _loadAll() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        ApiService.getDashboardStats(),
        ApiService.getAdminUsers(),
        ApiService.getExercises(),
        ApiService.getRecipes(),
      ]);
      setState(() {
        _stats     = results[0] as Map<String, dynamic>;
        _users     = results[1] as List<UserModel>;
        _exercises = results[2] as List<Map<String, dynamic>>;
        _recipes   = results[3] as List<Map<String, dynamic>>;
        _loading   = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) showError(context, 'خطأ في تحميل البيانات');
    }
  }

  @override
  Widget build(BuildContext context) {
    final ext = Theme.of(context).extension<AppColorsExtension>()!;

    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة الإدارة ⚙️', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Manrope')),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _loadAll),
          IconButton(
            icon: const Icon(Icons.logout_rounded, color: AppColors.red),
            onPressed: () async {
              await context.read<AppProvider>().logout();
              if (!mounted) return;
              Navigator.pushAndRemoveUntil(context,
                MaterialPageRoute(builder: (_) => const WelcomeScreen()), (_) => false);
            },
          ),
        ],
        bottom: TabBar(
          onTap: (i) => setState(() => _tab = i),
          indicatorColor: AppColors.lime,
          labelColor: AppColors.lime,
          unselectedLabelColor: AppColors.textMuted,
          labelStyle: const TextStyle(fontFamily: 'Manrope', fontWeight: FontWeight.w700, fontSize: 13),
          tabs: const [
            Tab(text: 'الإحصائيات'),
            Tab(text: 'المستخدمون'),
            Tab(text: 'التمارين'),
            Tab(text: 'الوصفات'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation(AppColors.lime)))
          : IndexedStack(index: _tab, children: [
              _buildDashboard(ext),
              _buildUsers(ext),
              _buildExercises(ext),
              _buildRecipes(ext),
            ]),
    );
  }

  Widget _buildDashboard(AppColorsExtension ext) {
    final stats = (_stats?['stats'] as Map?) ?? {};
    final users    = (stats['users']    as Map?) ?? {};
    final workouts = (stats['workouts'] as Map?) ?? {};
    final plans    = (stats['plans']    as Map?) ?? {};
    final topSports = (stats['topSports'] as List?) ?? [];

    return RefreshIndicator(onRefresh: _loadAll, color: AppColors.lime, child: SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        // Stats Grid
        GridView.count(
          crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.4,
          children: [
            _statCard('المستخدمون', '${users['total'] ?? 0}', Icons.people_rounded, AppColors.teal),
            _statCard('التمارين', '${workouts['total'] ?? 0}', Icons.fitness_center_rounded, AppColors.lime),
            _statCard('الخطط', '${plans['total'] ?? 0}', Icons.auto_awesome_rounded, AppColors.amber),
            _statCard('مستخدمون نشطون', '${users['active'] ?? 0}', Icons.check_circle_rounded, AppColors.green),
          ],
        ),
        const SizedBox(height: 20),
        const SectionLabel('أكثر الرياضات شيوعاً'),
        ...topSports.take(5).map((s) {
          final count = s['count'] ?? 0;
          final max   = (topSports.first['count'] ?? 1).toDouble();
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: AppCard(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('${s['sport']}', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
                  InfoBadge(label: '$count تمرين', color: AppColors.lime),
                ]),
                const SizedBox(height: 8),
                ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(
                  value: count / max, minHeight: 6,
                  backgroundColor: AppColors.limeBg,
                  valueColor: const AlwaysStoppedAnimation(AppColors.lime),
                )),
              ]),
            ),
          );
        }),
      ]),
    ));
  }

  Widget _statCard(String label, String value, IconData icon, Color color) => AppCard(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color, size: 24),
      const Spacer(),
      Text(value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: color, fontFamily: 'Manrope')),
      Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textMuted, fontFamily: 'Manrope')),
    ]),
  );

  Widget _buildUsers(AppColorsExtension ext) => ListView.builder(
    padding: const EdgeInsets.all(16),
    itemCount: _users.length,
    itemBuilder: (_, i) {
      final u = _users[i];
      return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: AppCard(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            CircleAvatar(radius: 22, backgroundColor: AppColors.limeBg,
              child: Text(u.firstName.isNotEmpty ? u.firstName[0] : '؟',
                style: const TextStyle(color: AppColors.lime, fontWeight: FontWeight.w900, fontFamily: 'Manrope')),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(u.fullName, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
              Text(u.email, style: TextStyle(fontSize: 11, color: ext.textSecondary, fontFamily: 'Manrope')),
              InfoBadge(label: u.plan, color: AppColors.lime),
            ])),
            // Toggle active
            IconButton(
              icon: Icon(u.isActive ? Icons.block_rounded : Icons.check_circle_rounded,
                color: u.isActive ? AppColors.red : AppColors.green),
              onPressed: () async {
                try {
                  await ApiService.toggleUserStatus(u.id);
                  _loadAll();
                } catch (e) { showError(context, e.toString()); }
              },
            ),
            // Delete
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.red),
              onPressed: () async {
                final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                  title: const Text('حذف المستخدم؟', style: TextStyle(fontFamily: 'Manrope')),
                  content: Text('سيتم حذف ${u.fullName} نهائياً', style: const TextStyle(fontFamily: 'Manrope')),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف', style: TextStyle(color: AppColors.red))),
                  ],
                ));
                if (ok == true) {
                  try { await ApiService.deleteUser(u.id); _loadAll(); }
                  catch (e) { showError(context, e.toString()); }
                }
              },
            ),
          ]),
        ),
      );
    },
  );

  Widget _buildExercises(AppColorsExtension ext) => Column(children: [
    Padding(
      padding: const EdgeInsets.all(16),
      child: LimeButton(
        label: '+ إضافة تمرين',
        onTap: () => _showExerciseForm(context),
      ),
    ),
    Expanded(child: ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      itemCount: _exercises.length,
      itemBuilder: (_, i) {
        final ex = _exercises[i];
        return Padding(padding: const EdgeInsets.only(bottom: 10), child: AppCard(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Text(ex['icon'] ?? '🧘', style: const TextStyle(fontSize: 32)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(ex['name'] ?? '', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
              Text('${ex['type']} • ${ex['duration']}', style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
            ])),
            IconButton(icon: const Icon(Icons.edit_rounded, color: AppColors.teal, size: 20), onPressed: () => _showExerciseForm(context, ex: ex)),
            IconButton(icon: const Icon(Icons.delete_outline_rounded, color: AppColors.red, size: 20),
              onPressed: () async {
                try { await ApiService.deleteExercise(ex['id']); _loadAll(); }
                catch (e) { showError(context, e.toString()); }
              }),
          ]),
        ));
      },
    )),
  ]);

  Widget _buildRecipes(AppColorsExtension ext) => Column(children: [
    Padding(
      padding: const EdgeInsets.all(16),
      child: LimeButton(label: '+ إضافة وصفة', onTap: () => _showRecipeForm(context)),
    ),
    Expanded(child: ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      itemCount: _recipes.length,
      itemBuilder: (_, i) {
        final r = _recipes[i];
        return Padding(padding: const EdgeInsets.only(bottom: 10), child: AppCard(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Text(r['icon'] ?? '🥗', style: const TextStyle(fontSize: 32)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(r['name'] ?? '', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
              Text(r['type'] ?? '', style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
            ])),
            InfoBadge(label: '${r['views'] ?? 0} مشاهدة', color: AppColors.teal),
          ]),
        ));
      },
    )),
  ]);

  void _showExerciseForm(BuildContext context, {Map? ex}) {
    final nameCtrl = TextEditingController(text: ex?['name']);
    final descCtrl = TextEditingController(text: ex?['description']);
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(ex == null ? 'إضافة تمرين' : 'تعديل تمرين', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Manrope')),
        const SizedBox(height: 16),
        TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'الاسم', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: descCtrl, maxLines: 3, decoration: const InputDecoration(labelText: 'الشرح', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        LimeButton(label: ex == null ? 'إضافة' : 'حفظ', onTap: () async {
          try {
            final body = {'name': nameCtrl.text, 'type': 'إطالة', 'description': descCtrl.text};
            if (ex == null) await ApiService.createExercise(body);
            else await ApiService.updateExercise(ex['id'], body);
            Navigator.pop(context);
            _loadAll();
          } catch (e) { showError(context, e.toString()); }
        }),
      ])),
    ));
  }

  void _showRecipeForm(BuildContext context) {
    final nameCtrl = TextEditingController();
    final benefitCtrl = TextEditingController();
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('إضافة وصفة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Manrope')),
        const SizedBox(height: 16),
        TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'اسم الوصفة', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: benefitCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'الفائدة', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        LimeButton(label: 'إضافة', onTap: () async {
          try {
            await ApiService.createRecipe({'name': nameCtrl.text, 'type': 'بعد التمرين', 'benefit': benefitCtrl.text, 'ingredients': []});
            Navigator.pop(context);
            _loadAll();
          } catch (e) { showError(context, e.toString()); }
        }),
      ])),
    ));
  }
}
