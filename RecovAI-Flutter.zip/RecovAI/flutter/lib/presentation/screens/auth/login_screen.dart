// lib/presentation/screens/auth/login_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../providers/app_provider.dart';
import '../../widgets/shared_widgets.dart';
import '../home/main_screen.dart';
import '../admin/admin_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtrl  = TextEditingController();
  final _passCtrl   = TextEditingController();
  bool _showPass    = false;
  bool _loading     = false;
  String? _error;

  Future<void> _login() async {
    if (!_emailCtrl.text.contains('@')) { setState(() => _error = 'بريد غير صحيح'); return; }
    if (_passCtrl.text.length < 6)      { setState(() => _error = 'كلمة المرور قصيرة'); return; }
    setState(() { _loading = true; _error = null; });
    try {
      await context.read<AppProvider>().login(email: _emailCtrl.text.trim(), password: _passCtrl.text);
      if (!mounted) return;
      final user = context.read<AppProvider>().user!;
      Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (_) => user.isAdmin ? const AdminScreen() : const MainScreen()),
        (_) => false,
      );
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final dk = Theme.of(context).brightness == Brightness.dark;
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 52),
            // Back
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(width: 42, height: 42, decoration: BoxDecoration(color: ext.cardBg, borderRadius: BorderRadius.circular(14), border: Border.all(color: ext.borderColor)),
                child: const Icon(Icons.arrow_back_ios_rounded, size: 18),
              ),
            ),
            const SizedBox(height: 40),
            const Text('👋', style: TextStyle(fontSize: 40)),
            const SizedBox(height: 8),
            const Text('أهلاً بعودتك!', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, fontFamily: 'Manrope')),
            Text('سجّل دخولك للمتابعة', style: TextStyle(fontSize: 14, color: ext.textSecondary, fontFamily: 'Manrope')),
            const SizedBox(height: 36),

            // Email
            _label('البريد الإلكتروني'),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Row(children: [
                const Icon(Icons.mail_outline_rounded, color: AppColors.textMuted, size: 20),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: _emailCtrl, keyboardType: TextInputType.emailAddress,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(border: InputBorder.none, hintText: 'ahmed@email.com', hintStyle: TextStyle(color: AppColors.textMuted)),
                  style: TextStyle(color: ext.textPrimary, fontFamily: 'Manrope', fontSize: 15),
                )),
              ]),
            ),
            const SizedBox(height: 14),

            // Password
            _label('كلمة المرور'),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              child: Row(children: [
                const Icon(Icons.lock_outline_rounded, color: AppColors.textMuted, size: 20),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: _passCtrl, obscureText: !_showPass,
                  decoration: const InputDecoration(border: InputBorder.none, hintText: '••••••••', hintStyle: TextStyle(color: AppColors.textMuted)),
                  style: TextStyle(color: ext.textPrimary, fontFamily: 'Manrope', fontSize: 15),
                )),
                IconButton(
                  icon: Icon(_showPass ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: AppColors.textMuted, size: 20),
                  onPressed: () => setState(() => _showPass = !_showPass),
                ),
              ]),
            ),

            if (_error != null) ...[
              const SizedBox(height: 12),
              Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.redBg, borderRadius: BorderRadius.circular(10)),
                child: Row(children: [
                  const Icon(Icons.error_outline_rounded, color: AppColors.red, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(_error!, style: const TextStyle(color: AppColors.red, fontSize: 13, fontFamily: 'Manrope'))),
                ]),
              ),
            ],
            const SizedBox(height: 28),

            LimeButton(label: 'تسجيل الدخول', loading: _loading, onTap: _login,
              trailing: Container(width: 36, height: 36, decoration: BoxDecoration(color: AppColors.text, borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.arrow_forward_rounded, color: AppColors.white, size: 20),
              ),
            ),

            const SizedBox(height: 16),
            Center(
              child: GestureDetector(
                onTap: () {/* forgot password modal */},
                child: Text('🔑 نسيت كلمة المرور؟', style: TextStyle(color: AppColors.lime, fontWeight: FontWeight.w700, fontSize: 13, fontFamily: 'Manrope')),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 7),
    child: Text(t.toUpperCase(), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.textMuted, fontFamily: 'Manrope')),
  );

  @override void dispose() { _emailCtrl.dispose(); _passCtrl.dispose(); super.dispose(); }
}
