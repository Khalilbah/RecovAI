// lib/presentation/screens/auth/register_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../providers/app_provider.dart';
import '../../widgets/shared_widgets.dart';
import '../home/main_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  int    _step     = 0;
  bool   _loading  = false;
  bool   _showPass = false;
  String? _error;

  // Step 0
  final _fnCtrl  = TextEditingController();
  final _lnCtrl  = TextEditingController();
  final _emCtrl  = TextEditingController();
  final _pwCtrl  = TextEditingController();

  // Step 1
  final _ageCtrl    = TextEditingController();
  final _weightCtrl = TextEditingController();
  final _heightCtrl = TextEditingController();
  String _gender   = 'ذكر';
  String _activity = 'متوسط';

  bool _v0() {
    if (_fnCtrl.text.trim().isEmpty) { setState(() => _error = 'أدخل الاسم'); return false; }
    if (_lnCtrl.text.trim().isEmpty) { setState(() => _error = 'أدخل اللقب'); return false; }
    if (!_emCtrl.text.contains('@'))  { setState(() => _error = 'بريد غير صحيح'); return false; }
    if (_pwCtrl.text.length < 6)      { setState(() => _error = 'كلمة المرور 6 أحرف'); return false; }
    _error = null; return true;
  }

  bool _v1() {
    if (_ageCtrl.text.isEmpty)    { setState(() => _error = 'أدخل عمرك'); return false; }
    if (_weightCtrl.text.isEmpty) { setState(() => _error = 'أدخل وزنك'); return false; }
    if (_heightCtrl.text.isEmpty) { setState(() => _error = 'أدخل طولك'); return false; }
    _error = null; return true;
  }

  Future<void> _register() async {
    if (!_v1()) return;
    setState(() => _loading = true);
    try {
      await context.read<AppProvider>().register(
        firstName:    _fnCtrl.text.trim(),
        lastName:     _lnCtrl.text.trim(),
        email:        _emCtrl.text.trim(),
        password:     _pwCtrl.text,
        age:          int.tryParse(_ageCtrl.text),
        weight:       double.tryParse(_weightCtrl.text),
        height:       double.tryParse(_heightCtrl.text),
        gender:       _gender,
        activityLevel:_activity,
      );
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(context,
        MaterialPageRoute(builder: (_) => const MainScreen()), (_) => false);
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(children: [
              GestureDetector(
                onTap: _step == 0 ? () => Navigator.pop(context) : () => setState(() { _step = 0; _error = null; }),
                child: Container(width: 42, height: 42, decoration: BoxDecoration(color: ext.cardBg, borderRadius: BorderRadius.circular(14), border: Border.all(color: ext.borderColor)),
                  child: const Icon(Icons.arrow_back_ios_rounded, size: 18),
                ),
              ),
              const Spacer(),
              Text('RECOV', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 2, color: AppColors.lime, fontFamily: 'Manrope')),
              const Spacer(),
              const SizedBox(width: 42),
            ]),
          ),
          // Progress
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('الخطوة ${_step + 1} / 2', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: ext.textSecondary, fontFamily: 'Manrope')),
                Text(_step == 0 ? '50%' : '100%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.lime, fontFamily: 'Manrope')),
              ]),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: LinearProgressIndicator(
                  value: _step == 0 ? 0.5 : 1.0,
                  minHeight: 6,
                  backgroundColor: ext.innerBg,
                  valueColor: const AlwaysStoppedAnimation(AppColors.lime),
                ),
              ),
            ]),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: _step == 0 ? _buildStep0(ext) : _buildStep1(ext),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildStep0(AppColorsExtension ext) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('أنشئ حسابك 👋', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, fontFamily: 'Manrope')),
    Text('أدخل بياناتك الشخصية للبدء', style: TextStyle(fontSize: 14, color: ext.textSecondary, fontFamily: 'Manrope')),
    const SizedBox(height: 28),
    Row(children: [
      Expanded(child: _field('الاسم', _fnCtrl, hint: 'أحمد')),
      const SizedBox(width: 12),
      Expanded(child: _field('اللقب', _lnCtrl, hint: 'العتيبي')),
    ]),
    const SizedBox(height: 14),
    _field('البريد الإلكتروني', _emCtrl, hint: 'ahmed@email.com', type: TextInputType.emailAddress, icon: Icons.mail_outline_rounded),
    const SizedBox(height: 14),
    _field('كلمة المرور', _pwCtrl, hint: '6 أحرف أو أكثر', obscure: !_showPass, icon: Icons.lock_outline_rounded,
      suffix: IconButton(icon: Icon(_showPass ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: AppColors.textMuted, size: 20),
        onPressed: () => setState(() => _showPass = !_showPass),
      ),
    ),
    if (_error != null) _errorBox(_error!),
    const SizedBox(height: 28),
    LimeButton(label: 'التالي', onTap: () { if (_v0()) setState(() => _step = 1); },
      trailing: const Icon(Icons.arrow_forward_rounded, size: 22),
    ),
  ]);

  Widget _buildStep1(AppColorsExtension ext) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('بياناتك الجسدية 💪', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, fontFamily: 'Manrope')),
    Text('لتخصيص خطة الاستشفاء بدقة', style: TextStyle(fontSize: 14, color: ext.textSecondary, fontFamily: 'Manrope')),
    const SizedBox(height: 24),
    // Gender
    _sectionLabel('الجنس'),
    Row(children: ['ذكر', 'أنثى'].map((g) => Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _gender = g),
        child: Container(
          margin: EdgeInsets.only(right: g == 'ذكر' ? 6 : 0, left: g == 'أنثى' ? 6 : 0),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _gender == g ? AppColors.limeBg : ext.cardBg,
            border: Border.all(color: _gender == g ? AppColors.lime : ext.borderColor, width: _gender == g ? 2.5 : 1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(children: [
            Text(g == 'ذكر' ? '👨' : '👩', style: const TextStyle(fontSize: 28)),
            const SizedBox(height: 6),
            Text(g, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: _gender == g ? AppColors.lime : ext.textPrimary, fontFamily: 'Manrope')),
          ]),
        ),
      ),
    )).toList()),
    const SizedBox(height: 16),
    // Metrics
    Row(children: [
      Expanded(child: _metricField('العمر', _ageCtrl, 'سنة')),
      const SizedBox(width: 8),
      Expanded(child: _metricField('الوزن', _weightCtrl, 'كغ', isDecimal: true)),
      const SizedBox(width: 8),
      Expanded(child: _metricField('الطول', _heightCtrl, 'سم', isDecimal: true)),
    ]),
    const SizedBox(height: 16),
    // Activity
    _sectionLabel('مستوى النشاط'),
    ...['مبتدئ', 'متوسط', 'متقدم'].map((a) {
      final desc = {'مبتدئ': '1-2 مرة أسبوعياً', 'متوسط': '3-4 مرات أسبوعياً', 'متقدم': '5+ مرات أسبوعياً'};
      final icons = {'مبتدئ': Icons.eco_rounded, 'متوسط': Icons.bolt_rounded, 'متقدم': Icons.emoji_events_rounded};
      return GestureDetector(
        onTap: () => setState(() => _activity = a),
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _activity == a ? AppColors.limeBg : ext.cardBg,
            border: Border.all(color: _activity == a ? AppColors.lime : ext.borderColor, width: _activity == a ? 2.5 : 1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: _activity == a ? AppColors.lime.withOpacity(0.25) : ext.innerBg, borderRadius: BorderRadius.circular(12)),
              child: Icon(icons[a], color: _activity == a ? AppColors.lime : AppColors.textMuted, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(a, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: _activity == a ? AppColors.lime : ext.textPrimary, fontFamily: 'Manrope')),
              Text(desc[a]!, style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
            ])),
            if (_activity == a) const Icon(Icons.check_circle_rounded, color: AppColors.lime),
          ]),
        ),
      );
    }),
    if (_error != null) _errorBox(_error!),
    const SizedBox(height: 24),
    LimeButton(label: '🚀 إنشاء الحساب والبدء', loading: _loading, onTap: _register,
      trailing: const Icon(Icons.arrow_forward_rounded, size: 22),
    ),
    const SizedBox(height: 24),
  ]);

  Widget _field(String label, TextEditingController ctrl, {
    String? hint, TextInputType? type, bool obscure = false,
    IconData? icon, Widget? suffix,
  }) {
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label.toUpperCase(), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.textMuted, fontFamily: 'Manrope')),
      const SizedBox(height: 7),
      AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        child: Row(children: [
          if (icon != null) ...[Icon(icon, color: AppColors.textMuted, size: 18), const SizedBox(width: 10)],
          Expanded(child: TextField(
            controller: ctrl, keyboardType: type, obscureText: obscure,
            textDirection: TextDirection.rtl,
            decoration: InputDecoration(border: InputBorder.none, hintText: hint, hintStyle: const TextStyle(color: AppColors.textMuted)),
            style: TextStyle(color: ext.textPrimary, fontFamily: 'Manrope', fontSize: 15),
          )),
          if (suffix != null) suffix,
        ]),
      ),
    ]);
  }

  Widget _metricField(String label, TextEditingController ctrl, String unit, {bool isDecimal = false}) {
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    return AppCard(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: ext.textSecondary, letterSpacing: 1, fontFamily: 'Manrope')),
        TextField(
          controller: ctrl,
          textAlign: TextAlign.center,
          keyboardType: TextInputType.numberWithOptions(decimal: isDecimal),
          decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.zero),
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: ext.textPrimary, fontFamily: 'Manrope'),
        ),
        Text(unit, style: const TextStyle(fontSize: 11, color: AppColors.textMuted, fontFamily: 'Manrope')),
      ]),
    );
  }

  Widget _sectionLabel(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(t.toUpperCase(), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.textMuted, fontFamily: 'Manrope')),
  );

  Widget _errorBox(String msg) => Padding(
    padding: const EdgeInsets.only(top: 12),
    child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.redBg, borderRadius: BorderRadius.circular(10)),
      child: Row(children: [
        const Icon(Icons.error_outline_rounded, color: AppColors.red, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: const TextStyle(color: AppColors.red, fontSize: 13, fontFamily: 'Manrope'))),
      ]),
    ),
  );

  @override void dispose() {
    for (final c in [_fnCtrl, _lnCtrl, _emCtrl, _pwCtrl, _ageCtrl, _weightCtrl, _heightCtrl]) c.dispose();
    super.dispose();
  }
}
