// lib/presentation/screens/auth/welcome_screen.dart
import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/services/api_service.dart';
import '../../providers/app_provider.dart';
import 'package:provider/provider.dart';
import 'login_screen.dart';
import 'register_screen.dart';
import '../home/main_screen.dart';
import '../admin/admin_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..forward();

  @override
  void initState() {
    super.initState();
    _checkSession();
  }

  Future<void> _checkSession() async {
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    final ok = await context.read<AppProvider>().restoreSession();
    if (!mounted) return;
    if (ok) {
      final user = context.read<AppProvider>().user!;
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => user.isAdmin ? const AdminScreen() : const MainScreen(),
      ));
    } else {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const WelcomeScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBg,
      body: Center(
        child: FadeTransition(
          opacity: _anim,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(24)),
              child: const Icon(Icons.bolt_rounded, size: 44, color: AppColors.text),
            ),
            const SizedBox(height: 16),
            const Text('RECOV', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 4, color: AppColors.lime, fontFamily: 'Manrope')),
            const SizedBox(height: 8),
            const Text('مدرب الاستشفاء الذكي', style: TextStyle(fontSize: 14, color: AppColors.darkSec, fontFamily: 'Manrope')),
            const SizedBox(height: 48),
            const SizedBox(width: 32, height: 32, child: CircularProgressIndicator(
              strokeWidth: 3, valueColor: AlwaysStoppedAnimation(AppColors.lime), strokeCap: StrokeCap.round,
            )),
          ]),
        ),
      ),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dk = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: Stack(children: [
        // Background blobs
        Positioned(top: -80, right: -60, child: Container(
          width: 260, height: 260,
          decoration: const BoxDecoration(color: Color(0x2EC8F135), shape: BoxShape.circle),
        )),
        Positioned(bottom: 0, left: -80, child: Container(
          width: 220, height: 220,
          decoration: const BoxDecoration(color: Color(0x1500BFB3), shape: BoxShape.circle),
        )),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 60),
              // Logo
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                decoration: BoxDecoration(
                  color: dk ? AppColors.darkCard : AppColors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 20)],
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 34, height: 34, decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.bolt_rounded, size: 20, color: AppColors.text),
                  ),
                  const SizedBox(width: 10),
                  const Text('RECOV', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.5, fontFamily: 'Manrope')),
                ]),
              ),
              const SizedBox(height: 48),
              // Hero text
              const Text('تعافَ أسرع\nوأذكى 🏆', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, height: 1.15, fontFamily: 'Manrope')),
              const SizedBox(height: 16),
              Text('خطط استشفاء مخصصة بالذكاء الاصطناعي Claude بناءً على تمارينك وجسمك.',
                style: TextStyle(fontSize: 15, color: dk ? AppColors.darkSec : AppColors.textSec, height: 1.6, fontFamily: 'Manrope')),
              const SizedBox(height: 40),
              // Features
              ...['🤖 Claude AI يصمم خطتك الشخصية', '💪 تمارين إطالة وتدليك دقيقة', '🥗 تغذية ونوم مخصصين', '📊 تتبع تقدمك أسبوعياً'].map((f) =>
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(children: [
                    Container(width: 28, height: 28, decoration: BoxDecoration(color: AppColors.limeBg, borderRadius: BorderRadius.circular(8)),
                      child: const Center(child: Icon(Icons.check_rounded, size: 16, color: AppColors.lime)),
                    ),
                    const SizedBox(width: 12),
                    Text(f, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: dk ? AppColors.darkText : AppColors.text, fontFamily: 'Manrope')),
                  ]),
                )
              ),
              const Spacer(),
              // Buttons
              SizedBox(
                width: double.infinity, height: 56,
                child: ElevatedButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen())),
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.lime, foregroundColor: AppColors.text,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    elevation: 0, textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, fontFamily: 'Manrope'),
                  ),
                  child: const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('ابدأ مجاناً 🚀'),
                    Icon(Icons.arrow_forward_rounded, size: 22),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity, height: 54,
                child: OutlinedButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: dk ? AppColors.darkBorder : AppColors.border, width: 1.5),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    foregroundColor: dk ? AppColors.darkText : AppColors.text,
                    textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, fontFamily: 'Manrope'),
                  ),
                  child: const Text('تسجيل الدخول'),
                ),
              ),
              const SizedBox(height: 32),
            ]),
          ),
        ),
      ]),
    );
  }
}
