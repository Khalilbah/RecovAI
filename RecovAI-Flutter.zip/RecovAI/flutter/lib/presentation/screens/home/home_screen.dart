// lib/presentation/screens/home/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../providers/app_provider.dart';
import '../../widgets/shared_widgets.dart';
import '../log/log_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final user = provider.user;
    final plan = provider.currentPlan;
    final workouts = provider.workouts;
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    final dk = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: CustomScrollView(slivers: [
        // App Bar
        SliverAppBar(
          floating: true,
          backgroundColor: dk ? AppColors.darkBg.withOpacity(0.95) : AppColors.bg.withOpacity(0.95),
          title: Row(children: [
            Container(width: 30, height: 30, decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(9)),
              child: const Icon(Icons.bolt_rounded, size: 18, color: AppColors.text),
            ),
            const SizedBox(width: 8),
            const Text('RECOV', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1, fontFamily: 'Manrope')),
          ]),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: CircleAvatar(
                radius: 18,
                backgroundColor: AppColors.limeBg,
                child: user?.photoUrl != null
                    ? null
                    : Text(user?.firstName.isNotEmpty == true ? user!.firstName[0] : '؟',
                        style: const TextStyle(color: AppColors.lime, fontWeight: FontWeight.w900, fontFamily: 'Manrope')),
              ),
            ),
          ],
        ),

        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Greeting
              Text('مرحباً ${user?.firstName ?? ''} 👋',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, fontFamily: 'Manrope')),
              Text('جاهز للتعافي اليوم؟', style: TextStyle(fontSize: 14, color: ext.textSecondary, fontFamily: 'Manrope')),
              const SizedBox(height: 24),

              // Recovery Score Card
              if (plan != null) ...[
                AppCard(
                  color: AppColors.darkBg,
                  child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('درجة التعافي', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.darkSec, fontFamily: 'Manrope')),
                      const SizedBox(height: 8),
                      Text(plan.summary, maxLines: 3, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13, color: AppColors.darkText, height: 1.6, fontFamily: 'Manrope')),
                      const SizedBox(height: 14),
                      GestureDetector(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LogScreen())),
                        child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(color: AppColors.lime, borderRadius: BorderRadius.circular(10)),
                          child: const Text('عرض الخطة', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.text, fontFamily: 'Manrope')),
                        ),
                      ),
                    ])),
                    const SizedBox(width: 16),
                    ScoreRing(score: plan.recoveryScore),
                  ]),
                ),
                const SizedBox(height: 16),
              ],

              // Quick Log Button
              AppCard(
                color: AppColors.lime,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LogScreen())),
                child: Row(children: [
                  const Icon(Icons.add_circle_rounded, color: AppColors.text, size: 28),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('سجّل تمريناً', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.text, fontFamily: 'Manrope')),
                    Text(plan == null ? 'احصل على خطة استشفاء مخصصة' : 'تمرين جديد؟ خطة جديدة!',
                      style: TextStyle(fontSize: 12, color: AppColors.text.withOpacity(0.65), fontFamily: 'Manrope')),
                  ])),
                  const Icon(Icons.arrow_forward_ios_rounded, color: AppColors.text, size: 18),
                ]),
              ),
              const SizedBox(height: 20),

              // Stats row
              if (workouts.isNotEmpty) ...[
                const SectionLabel('إحصائياتك'),
                Row(children: [
                  _statCard(context, '${workouts.length}', 'تمرين', Icons.fitness_center_rounded, AppColors.teal),
                  const SizedBox(width: 10),
                  _statCard(context, '${workouts.fold(0, (s, w) => s + w.duration)}', 'دقيقة', Icons.timer_rounded, AppColors.amber),
                  const SizedBox(width: 10),
                  _statCard(context, '${plan?.recoveryScore ?? 0}', 'نقطة', Icons.star_rounded, AppColors.lime),
                ]),
                const SizedBox(height: 20),
              ],

              // Recent Workouts
              if (workouts.isNotEmpty) ...[
                const SectionLabel('آخر التمارين'),
                ...workouts.take(3).map((w) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: AppCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      Container(width: 44, height: 44, decoration: BoxDecoration(color: AppColors.limeBg, borderRadius: BorderRadius.circular(12)),
                        child: Center(child: Text(_sportEmoji(w.sport), style: const TextStyle(fontSize: 22))),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(w.sport, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
                        Text('${w.duration} دقيقة • ${w.intensity}', style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
                      ])),
                      InfoBadge(label: w.intensity, color: w.intensityColor),
                    ]),
                  ),
                )),
              ],

              // Empty state
              if (workouts.isEmpty) ...[
                const SizedBox(height: 40),
                Center(child: Column(children: [
                  const Text('🏋️', style: TextStyle(fontSize: 64)),
                  const SizedBox(height: 16),
                  const Text('لا تمارين بعد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Manrope')),
                  Text('سجّل أول تمرين واحصل على خطة استشفاء من Claude AI',
                    style: TextStyle(fontSize: 13, color: ext.textSecondary, fontFamily: 'Manrope'), textAlign: TextAlign.center),
                ])),
              ],
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _statCard(BuildContext context, String value, String label, IconData icon, Color color) {
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    return Expanded(
      child: AppCard(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: color, fontFamily: 'Manrope')),
          Text(label, style: TextStyle(fontSize: 11, color: ext.textSecondary, fontFamily: 'Manrope')),
        ]),
      ),
    );
  }

  String _sportEmoji(String sport) {
    const map = {'جيم': '🏋️', 'جري': '🏃', 'سباحة': '🏊', 'دراجة': '🚴', 'كرة قدم': '⚽', 'تنس': '🎾'};
    return map[sport] ?? '⚡';
  }
}
