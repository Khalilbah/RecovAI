// lib/presentation/screens/log/log_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/models/models.dart';
import '../../providers/app_provider.dart';
import '../../widgets/shared_widgets.dart';

class LogScreen extends StatefulWidget {
  const LogScreen({super.key});
  @override State<LogScreen> createState() => _LogScreenState();
}

class _LogScreenState extends State<LogScreen> with SingleTickerProviderStateMixin {
  late TabController _tabs;
  String _sport    = 'جيم';
  String _inten    = 'متوسط';
  String _timeOfDay= 'مسائي';
  int    _dur      = 45;
  final Set<String> _zones = {};
  bool   _generating = false;
  int    _genStep    = 0;

  static const _sports     = ['جيم', 'جري', 'سباحة', 'دراجة', 'كرة قدم', 'تنس', 'ملاكمة', 'يوغا'];
  static const _intensities = ['خفيف', 'متوسط', 'عالي'];
  static const _timesOfDay = ['صباحي', 'مسائي', 'ليلي'];
  static const _bodyZones  = ['أرجل', 'ظهر', 'أكتاف', 'صدر', 'ذراعين', 'جسم كامل'];
  static const _genSteps   = ['يحلل نوع التمرين...', 'يفحص مناطق التعب...', 'يُعدّ تمارين الإطالة...', 'يصمم التغذية...', 'جاري إنهاء الخطة...'];

  @override
  void initState() {
    super.initState();
    final hasPlan = context.read<AppProvider>().currentPlan != null;
    _tabs = TabController(length: 2, vsync: this, initialIndex: hasPlan ? 1 : 0);
  }

  Future<void> _generate() async {
    if (_zones.isEmpty) { showError(context, 'اختر منطقة تعب واحدة على الأقل'); return; }
    setState(() { _generating = true; _genStep = 0; });
    // Animate steps
    final timer = Stream.periodic(const Duration(milliseconds: 1400))
        .listen((_) { if (mounted) setState(() => _genStep = (_genStep + 1) % _genSteps.length); });
    try {
      final plan = await context.read<AppProvider>().generatePlan(WorkoutModel(
        sport: _sport, duration: _dur, intensity: _inten, timeOfDay: _timeOfDay, zones: _zones.toList(),
      ));
      timer.cancel();
      if (!mounted) return;
      setState(() => _generating = false);
      _tabs.animateTo(1);
      showSuccess(context, '✅ تم إنشاء خطة الاستشفاء بواسطة Claude AI');
    } catch (e) {
      timer.cancel();
      if (!mounted) return;
      setState(() => _generating = false);
      showError(context, 'خطأ: ${e.toString()}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final plan = context.watch<AppProvider>().currentPlan;
    final ext  = Theme.of(context).extension<AppColorsExtension>()!;

    return Scaffold(
      body: Stack(children: [
        NestedScrollView(
          headerSliverBuilder: (_, __) => [
            SliverAppBar(
              title: const Text('التمرين والخطة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Manrope')),
              pinned: true,
              bottom: TabBar(
                controller: _tabs,
                indicatorColor: AppColors.lime,
                indicatorWeight: 3,
                labelColor: AppColors.lime,
                unselectedLabelColor: AppColors.textMuted,
                labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontFamily: 'Manrope', fontSize: 14),
                tabs: const [Tab(text: 'سجّل تمريناً'), Tab(text: '🤖 خطة Claude')],
              ),
            ),
          ],
          body: TabBarView(controller: _tabs, children: [
            _buildLogTab(ext),
            _buildPlanTab(plan, ext),
          ]),
        ),
        if (_generating) _buildGeneratingOverlay(),
      ]),
    );
  }

  Widget _buildLogTab(AppColorsExtension ext) => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Sport
      const SectionLabel('نوع الرياضة'),
      SizedBox(
        height: 46,
        child: ListView(scrollDirection: Axis.horizontal, children: _sports.map((s) =>
          Padding(padding: const EdgeInsets.only(left: 8), child: SelectChip(label: '${ _sportEmoji(s)} $s', selected: _sport == s, onTap: () => setState(() => _sport = s))),
        ).toList()),
      ),
      // Duration
      const SectionLabel('المدة'),
      AppCard(
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('$_dur دقيقة', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.lime, fontFamily: 'Manrope')),
            InfoBadge(label: _dur < 30 ? 'قصير' : _dur < 60 ? 'متوسط' : 'طويل', color: AppColors.teal),
          ]),
          Slider(
            value: _dur.toDouble(), min: 15, max: 180, divisions: 33,
            activeColor: AppColors.lime, inactiveColor: AppColors.limeBg,
            onChanged: (v) => setState(() => _dur = v.round()),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('15 دقيقة', style: TextStyle(fontSize: 11, color: ext.textSecondary, fontFamily: 'Manrope')),
            Text('180 دقيقة', style: TextStyle(fontSize: 11, color: ext.textSecondary, fontFamily: 'Manrope')),
          ]),
        ]),
      ),
      // Intensity
      const SectionLabel('شدة التمرين'),
      Row(children: _intensities.map((i) {
        final colors = {'خفيف': AppColors.green, 'متوسط': AppColors.amber, 'عالي': AppColors.red};
        return Expanded(child: Padding(
          padding: EdgeInsets.only(left: i != 'خفيف' ? 8 : 0),
          child: GestureDetector(
            onTap: () => setState(() => _inten = i),
            child: AnimatedContainer(duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                color: _inten == i ? colors[i]!.withOpacity(0.15) : ext.cardBg,
                border: Border.all(color: _inten == i ? colors[i]! : ext.borderColor, width: _inten == i ? 2 : 1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(children: [
                Text({'خفيف': '😊', 'متوسط': '😤', 'عالي': '🔥'}[i]!, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 4),
                Text(i, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: _inten == i ? colors[i]! : ext.textSecondary, fontFamily: 'Manrope')),
              ]),
            ),
          ),
        ));
      }).toList()),
      // Time of day
      const SectionLabel('وقت التمرين'),
      Row(children: _timesOfDay.map((t) => Expanded(child: Padding(
        padding: EdgeInsets.only(left: t != 'صباحي' ? 8 : 0),
        child: SelectChip(label: '${ {'صباحي':'🌅','مسائي':'🌆','ليلي':'🌙'}[t]!} $t', selected: _timeOfDay == t,
          onTap: () => setState(() => _timeOfDay = t), activeColor: AppColors.teal),
      ))).toList()),
      // Fatigue Zones
      const SectionLabel('مناطق التعب'),
      Wrap(spacing: 8, runSpacing: 8, children: _bodyZones.map((z) => SelectChip(
        label: '${ {'أرجل':'🦵','ظهر':'🔙','أكتاف':'💪','صدر':'🫀','ذراعين':'💪','جسم كامل':'🌐'}[z]!} $z',
        selected: _zones.contains(z),
        onTap: () => setState(() => _zones.contains(z) ? _zones.remove(z) : _zones.add(z)),
        activeColor: AppColors.red,
      )).toList()),
      const SizedBox(height: 32),
      // Generate Button
      LimeButton(
        label: '🤖 إنشاء خطة الاستشفاء بـ Claude',
        onTap: _generate,
        trailing: Container(width: 36, height: 36, decoration: BoxDecoration(color: AppColors.text, borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.auto_awesome_rounded, color: AppColors.lime, size: 20),
        ),
      ),
    ]),
  );

  Widget _buildPlanTab(RecoveryPlanModel? plan, AppColorsExtension ext) {
    if (plan == null) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('🤖', style: TextStyle(fontSize: 64)),
      const SizedBox(height: 16),
      const Text('لا توجد خطة بعد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Manrope')),
      Text('سجّل تمريناً واضغط "إنشاء الخطة"', style: TextStyle(fontSize: 13, color: ext.textSecondary, fontFamily: 'Manrope')),
    ]));

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
      child: Column(children: [
        // Recovery Score
        AppCard(
          color: AppColors.darkBg,
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('درجة التعافي', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.darkSec, fontFamily: 'Manrope')),
                const SizedBox(height: 8),
                Text(plan.summary, style: const TextStyle(fontSize: 13, color: AppColors.darkText, height: 1.7, fontFamily: 'Manrope')),
              ])),
              const SizedBox(width: 16),
              ScoreRing(score: plan.recoveryScore),
            ]),
            if (plan.warnings.isNotEmpty) ...[
              const SizedBox(height: 16),
              ...plan.warnings.map((w) => Container(
                padding: const EdgeInsets.all(12), margin: const EdgeInsets.only(top: 8),
                decoration: BoxDecoration(color: AppColors.redBg, borderRadius: BorderRadius.circular(10)),
                child: Row(children: [
                  const Icon(Icons.warning_rounded, color: AppColors.red, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(w, style: const TextStyle(color: AppColors.red, fontSize: 12, fontFamily: 'Manrope'))),
                ]),
              )),
            ],
          ]),
        ),
        // Stretching
        const SectionLabel('تمارين الإطالة'),
        ...plan.stretching.exercises.map((ex) => _exerciseCard(ex, ext)),
        // Hydration
        const SectionLabel('الترطيب 💧'),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const IconBox(icon: Icons.water_drop_rounded, bg: Color(0x1A00BFB3), iconColor: AppColors.teal),
              const SizedBox(width: 14),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(plan.hydration.amount, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.teal, fontFamily: 'Manrope')),
                Text(plan.hydration.schedule, style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
              ]),
            ]),
            const SizedBox(height: 12),
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0x1A00BFB3), borderRadius: BorderRadius.circular(10)),
              child: Text(plan.hydration.tip, style: const TextStyle(fontSize: 13, color: AppColors.teal, fontFamily: 'Manrope'))),
          ]),
        ),
        // Sleep
        const SectionLabel('النوم 🌙'),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const IconBox(icon: Icons.nightlight_round, bg: Color(0x1AF5A623), iconColor: AppColors.amber),
              const SizedBox(width: 14),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(plan.sleep.hours, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.amber, fontFamily: 'Manrope')),
                Text('النوم: ${plan.sleep.bedtime}', style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
              ]),
            ]),
            const SizedBox(height: 12),
            ...plan.sleep.tips.map((t) => Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.check_circle_rounded, color: AppColors.amber, size: 16),
                const SizedBox(width: 8),
                Expanded(child: Text(t, style: TextStyle(fontSize: 13, color: ext.textPrimary, fontFamily: 'Manrope', height: 1.5))),
              ]),
            )),
          ]),
        ),
        // Nutrition
        const SectionLabel('التغذية 🥗'),
        ...plan.nutrition.meals.map((meal) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text(meal.icon, style: const TextStyle(fontSize: 36)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(meal.name, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: ext.textPrimary, fontFamily: 'Manrope')),
                  InfoBadge(label: meal.timing, color: AppColors.green),
                ])),
              ]),
              const SizedBox(height: 12),
              Text('المكونات:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: ext.textSecondary, letterSpacing: 1, fontFamily: 'Manrope')),
              const SizedBox(height: 6),
              Wrap(spacing: 6, runSpacing: 6, children: meal.ingredients.map((i) =>
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: AppColors.greenBg, borderRadius: BorderRadius.circular(8)),
                  child: Text(i, style: const TextStyle(fontSize: 12, color: AppColors.green, fontWeight: FontWeight.w600, fontFamily: 'Manrope')),
                )
              ).toList()),
              const SizedBox(height: 10),
              Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: AppColors.greenBg, borderRadius: BorderRadius.circular(10)),
                child: Text(meal.benefit, style: const TextStyle(fontSize: 12, color: AppColors.green, fontFamily: 'Manrope'))),
            ]),
          ),
        )),
        // Massage
        if (plan.massage.isNotEmpty) ...[
          const SectionLabel('التدليك 💆'),
          ...plan.massage.map((m) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: AppCard(
              child: Row(children: [
                Text(m.icon, style: const TextStyle(fontSize: 36)),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(m.name, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
                  Text(m.duration, style: const TextStyle(fontSize: 12, color: AppColors.teal, fontFamily: 'Manrope')),
                  const SizedBox(height: 6),
                  Text(m.desc, style: TextStyle(fontSize: 12, color: ext.textSecondary, height: 1.5, fontFamily: 'Manrope')),
                ])),
              ]),
            ),
          )),
        ],
      ]),
    );
  }

  Widget _exerciseCard(ExerciseItem ex, AppColorsExtension ext) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: AppCard(
      child: Row(children: [
        Text(ex.icon, style: const TextStyle(fontSize: 32)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(ex.name, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
          const SizedBox(height: 4),
          Text(ex.description, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, color: ext.textSecondary, height: 1.5, fontFamily: 'Manrope')),
        ])),
        const SizedBox(width: 8),
        InfoBadge(label: ex.duration, color: AppColors.lime),
      ]),
    ),
  );

  Widget _buildGeneratingOverlay() => Positioned.fill(
    child: Container(
      color: Colors.black54,
      child: Center(
        child: AppCard(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(width: 60, height: 60, child: CircularProgressIndicator(
              strokeWidth: 4, valueColor: AlwaysStoppedAnimation(AppColors.lime), strokeCap: StrokeCap.round,
            )),
            const SizedBox(height: 20),
            const Text('🤖 Claude AI', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.lime, fontFamily: 'Manrope')),
            const SizedBox(height: 8),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              child: Text(_genSteps[_genStep], key: ValueKey(_genStep),
                style: const TextStyle(fontSize: 14, color: AppColors.textMuted, fontFamily: 'Manrope'), textAlign: TextAlign.center),
            ),
          ]),
        ),
      ),
    ),
  );

  String _sportEmoji(String s) {
    const m = {'جيم':'🏋️','جري':'🏃','سباحة':'🏊','دراجة':'🚴','كرة قدم':'⚽','تنس':'🎾','ملاكمة':'🥊','يوغا':'🧘'};
    return m[s] ?? '⚡';
  }

  @override void dispose() { _tabs.dispose(); super.dispose(); }
}
