// lib/presentation/screens/progress/progress_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../providers/app_provider.dart';
import '../../widgets/shared_widgets.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final workouts = context.watch<AppProvider>().workouts;
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    // Stats
    final total = workouts.length;
    final totalMins = workouts.fold(0, (s, w) => s + w.duration);
    final highCount = workouts.where((w) => w.intensity == 'عالي').length;

    return Scaffold(
      appBar: AppBar(title: const Text('التقدم 📊', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, fontFamily: 'Manrope'))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
        child: Column(children: [
          const SizedBox(height: 8),
          // Summary cards
          Row(children: [
            _statCard(context, '$total', 'تمرين كلي', AppColors.lime),
            const SizedBox(width: 10),
            _statCard(context, '${(totalMins / 60).toStringAsFixed(1)}', 'ساعة', AppColors.teal),
            const SizedBox(width: 10),
            _statCard(context, '$highCount', 'شديد', AppColors.red),
          ]),
          const SizedBox(height: 20),
          if (workouts.isEmpty) ...[
            const SizedBox(height: 60),
            const Text('📊', style: TextStyle(fontSize: 60)),
            const SizedBox(height: 16),
            const Text('لا بيانات بعد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Manrope')),
          ] else ...[
            const SectionLabel('التمارين الأخيرة'),
            ...workouts.map((w) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppCard(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Container(width: 44, height: 44, decoration: BoxDecoration(
                    color: w.intensityColor.withOpacity(0.12), borderRadius: BorderRadius.circular(12),
                  ), child: Center(child: Icon(Icons.fitness_center_rounded, color: w.intensityColor, size: 22))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(w.sport, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
                    Text('${w.duration} دقيقة • ${w.zones.join("، ")}',
                      style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
                  ])),
                  InfoBadge(label: w.intensity, color: w.intensityColor),
                ]),
              ),
            )),
          ],
        ]),
      ),
    );
  }

  Widget _statCard(BuildContext context, String v, String l, Color c) {
    return Expanded(child: AppCard(
      padding: const EdgeInsets.symmetric(vertical: 18),
      child: Column(children: [
        Text(v, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: c, fontFamily: 'Manrope')),
        const SizedBox(height: 4),
        Text(l, style: const TextStyle(fontSize: 11, color: AppColors.textMuted, fontFamily: 'Manrope')),
      ]),
    ));
  }
}
