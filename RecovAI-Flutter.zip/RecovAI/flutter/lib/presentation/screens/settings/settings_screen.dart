// lib/presentation/screens/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../providers/app_provider.dart';
import '../../widgets/shared_widgets.dart';
import '../auth/welcome_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    final user = provider.user;
    final ext  = Theme.of(context).extension<AppColorsExtension>()!;
    final dk   = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات ⚙️', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, fontFamily: 'Manrope'))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
        child: Column(children: [
          const SizedBox(height: 8),
          // Profile Card
          AppCard(
            padding: const EdgeInsets.all(20),
            child: Row(children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: AppColors.limeBg,
                child: user?.photoUrl != null
                    ? null
                    : Text(user?.firstName.isNotEmpty == true ? user!.firstName[0] : '؟',
                        style: const TextStyle(fontSize: 24, color: AppColors.lime, fontWeight: FontWeight.w900, fontFamily: 'Manrope')),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(user?.fullName ?? '', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: ext.textPrimary, fontFamily: 'Manrope')),
                Text(user?.email ?? '', style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
                if (user?.plan != null) InfoBadge(label: user!.plan, color: AppColors.lime),
              ])),
              if (user?.weight != null)
                Column(children: [
                  Text('${user!.weight?.toStringAsFixed(0)} كغ', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.lime, fontFamily: 'Manrope')),
                  Text('${user.height?.toStringAsFixed(0)} سم', style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
                ]),
            ]),
          ),
          const SizedBox(height: 16),
          // Theme
          AppCard(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('المظهر', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.textMuted, fontFamily: 'Manrope')),
              const SizedBox(height: 12),
              Row(children: [
                {'id': ThemeMode.light, 'label': 'فاتح', 'icon': Icons.wb_sunny_rounded},
                {'id': ThemeMode.dark,  'label': 'داكن', 'icon': Icons.nightlight_round},
                {'id': ThemeMode.system,'label': 'النظام','icon': Icons.phone_android_rounded},
              ].map((m) => Expanded(child: GestureDetector(
                onTap: () => provider.setTheme(m['id'] as ThemeMode),
                child: AnimatedContainer(duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: provider.themeMode == m['id'] ? AppColors.limeBg : Colors.transparent,
                    border: Border.all(color: provider.themeMode == m['id'] ? AppColors.lime : ext.borderColor, width: provider.themeMode == m['id'] ? 2 : 1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(children: [
                    Icon(m['icon'] as IconData, color: provider.themeMode == m['id'] ? AppColors.lime : AppColors.textMuted, size: 20),
                    const SizedBox(height: 4),
                    Text(m['label'] as String, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: provider.themeMode == m['id'] ? AppColors.lime : AppColors.textMuted, fontFamily: 'Manrope')),
                  ]),
                ),
              ))).toList()),
            ]),
          ),
          const SizedBox(height: 10),
          // Menu Items
          ...[
            {'icon': Icons.notifications_rounded, 'label': 'الإشعارات', 'sub': 'تفعيل التذكيرات', 'color': AppColors.amber, 'action': null},
            {'icon': Icons.card_membership_rounded, 'label': 'الاشتراك', 'sub': user?.plan ?? 'مجانية', 'color': AppColors.lime, 'action': null},
            {'icon': Icons.security_rounded, 'label': 'الأمان', 'sub': 'تغيير كلمة المرور', 'color': AppColors.green, 'action': null},
            {'icon': Icons.help_outline_rounded, 'label': 'الدعم', 'sub': 'تواصل معنا', 'color': AppColors.teal, 'action': null},
          ].map((item) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: AppCard(
              onTap: item['action'] as VoidCallback?,
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                IconBox(icon: item['icon'] as IconData, bg: (item['color'] as Color).withOpacity(0.12), iconColor: item['color'] as Color),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item['label'] as String, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: ext.textPrimary, fontFamily: 'Manrope')),
                  Text(item['sub'] as String, style: TextStyle(fontSize: 12, color: ext.textSecondary, fontFamily: 'Manrope')),
                ])),
                Icon(Icons.chevron_right_rounded, color: ext.textSecondary),
              ]),
            ),
          )),
          // API Status
          _ApiStatusCard(),
          const SizedBox(height: 10),
          // Logout
          AppCard(
            onTap: () async {
              await provider.logout();
              if (!context.mounted) return;
              Navigator.pushAndRemoveUntil(context,
                MaterialPageRoute(builder: (_) => const WelcomeScreen()), (_) => false);
            },
            padding: const EdgeInsets.all(16),
            border: Border.all(color: AppColors.red.withOpacity(0.3)),
            child: Row(children: [
              IconBox(icon: Icons.logout_rounded, bg: AppColors.redBg, iconColor: AppColors.red),
              const SizedBox(width: 14),
              const Expanded(child: Text('تسجيل الخروج', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.red, fontFamily: 'Manrope'))),
              const Icon(Icons.chevron_right_rounded, color: AppColors.red),
            ]),
          ),
          const SizedBox(height: 16),
          const Text('RecovAI v1.0 — Powered by Claude AI', style: TextStyle(fontSize: 12, color: AppColors.textMuted, fontFamily: 'Manrope')),
        ]),
      ),
    );
  }
}

class _ApiStatusCard extends StatefulWidget {
  @override State<_ApiStatusCard> createState() => _ApiStatusCardState();
}
class _ApiStatusCardState extends State<_ApiStatusCard> {
  bool? _online;
  @override void initState() { super.initState(); _check(); }
  Future<void> _check() async {
    final ok = await ApiService_checkHealth();
    if (mounted) setState(() => _online = ok);
  }
  Future<bool> ApiService_checkHealth() async {
    try {
      final res = await Future.any([
        Uri.parse('http://10.0.2.2:3000/api/health').let((u) async {
          final r = await http_get(u); return r.statusCode == 200;
        }),
        Future.delayed(const Duration(seconds: 4), () => false),
      ]);
      return res;
    } catch (_) { return false; }
  }
  @override Widget build(BuildContext context) {
    if (_online == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _online! ? AppColors.greenBg : AppColors.redBg,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(
            color: _online! ? AppColors.green : AppColors.red, shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: (_online! ? AppColors.green : AppColors.red).withOpacity(0.5), blurRadius: 6)],
          )),
          const SizedBox(width: 10),
          Text(_online! ? '✅ متصل بالخادم' : '⚠️ الخادم غير متاح',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _online! ? AppColors.green : AppColors.red, fontFamily: 'Manrope')),
        ]),
      ),
    );
  }
}

// Note: replace http_get with actual http.get in real implementation
Future http_get(Uri u) async => throw UnimplementedError();
