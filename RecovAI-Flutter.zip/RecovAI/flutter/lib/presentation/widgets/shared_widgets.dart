// lib/presentation/widgets/shared_widgets.dart
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

// ─── Lime Primary Button ───────────────────────────────────────────────────────
class LimeButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool loading;
  final bool fullWidth;
  final Widget? trailing;
  const LimeButton({super.key, required this.label, this.onTap, this.loading=false, this.fullWidth=true, this.trailing});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: 56,
      child: Material(
        color: AppColors.lime,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          onTap: loading ? null : onTap,
          borderRadius: BorderRadius.circular(18),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              mainAxisAlignment: trailing != null ? MainAxisAlignment.spaceBetween : MainAxisAlignment.center,
              children: [
                if (loading)
                  const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: AppColors.text))
                else
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: AppColors.text, fontFamily: 'Manrope')),
                if (trailing != null && !loading) trailing!,
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── App Card ─────────────────────────────────────────────────────────────────
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final VoidCallback? onTap;
  final Color? color;
  final double radius;
  final Border? border;

  const AppCard({super.key, required this.child, this.padding, this.onTap, this.color, this.radius = 20, this.border});

  @override
  Widget build(BuildContext context) {
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    return Container(
      decoration: BoxDecoration(
        color:        color ?? ext.cardBg,
        borderRadius: BorderRadius.circular(radius),
        border:       border ?? Border.all(color: ext.borderColor, width: 1),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 14, offset: const Offset(0, 4))],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(radius),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(radius),
          child: Padding(padding: padding ?? const EdgeInsets.all(18), child: child),
        ),
      ),
    );
  }
}

// ─── Score Ring ───────────────────────────────────────────────────────────────
class ScoreRing extends StatelessWidget {
  final int score;
  final double size;
  const ScoreRing({super.key, required this.score, this.size = 110});

  Color get color {
    if (score >= 80) return AppColors.green;
    if (score >= 60) return AppColors.amber;
    return AppColors.red;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size, height: size,
      child: Stack(alignment: Alignment.center, children: [
        SizedBox(
          width: size, height: size,
          child: CircularProgressIndicator(
            value: score / 100,
            strokeWidth: 9,
            backgroundColor: color.withOpacity(0.15),
            valueColor: AlwaysStoppedAnimation(color),
            strokeCap: StrokeCap.round,
          ),
        ),
        Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('$score', style: TextStyle(fontSize: size * 0.28, fontWeight: FontWeight.w900, color: color, fontFamily: 'Manrope')),
          Text('/ 100', style: TextStyle(fontSize: size * 0.11, color: AppColors.textMuted, fontFamily: 'Manrope')),
        ]),
      ]),
    );
  }
}

// ─── Section Label ────────────────────────────────────────────────────────────
class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 10),
      child: Text(text.toUpperCase(),
        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.5, color: AppColors.textMuted, fontFamily: 'Manrope'),
      ),
    );
  }
}

// ─── Chip selector ────────────────────────────────────────────────────────────
class SelectChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color? activeColor;
  const SelectChip({super.key, required this.label, required this.selected, required this.onTap, this.activeColor});

  @override
  Widget build(BuildContext context) {
    final ext = Theme.of(context).extension<AppColorsExtension>()!;
    final col = activeColor ?? AppColors.lime;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color:  selected ? col.withOpacity(0.15) : ext.innerBg,
          border: Border.all(color: selected ? col : ext.borderColor, width: selected ? 2 : 1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: selected ? col : ext.textSecondary, fontFamily: 'Manrope')),
      ),
    );
  }
}

// ─── Info Badge ───────────────────────────────────────────────────────────────
class InfoBadge extends StatelessWidget {
  final String label;
  final Color color;
  const InfoBadge({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(color: color.withOpacity(0.13), borderRadius: BorderRadius.circular(8)),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: color, fontFamily: 'Manrope')),
    );
  }
}

// ─── Icon Box ─────────────────────────────────────────────────────────────────
class IconBox extends StatelessWidget {
  final IconData icon;
  final Color bg;
  final Color iconColor;
  final double size;
  const IconBox({super.key, required this.icon, required this.bg, required this.iconColor, this.size = 44});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(size * 0.3)),
      child: Icon(icon, color: iconColor, size: size * 0.45),
    );
  }
}

// ─── Loading overlay ──────────────────────────────────────────────────────────
class LoadingOverlay extends StatefulWidget {
  final List<String> steps;
  const LoadingOverlay({super.key, required this.steps});
  @override State<LoadingOverlay> createState() => _LoadingOverlayState();
}

class _LoadingOverlayState extends State<LoadingOverlay> {
  int _step = 0;
  late final _timer = Stream.periodic(const Duration(milliseconds: 1400));

  @override
  void initState() {
    super.initState();
    _timer.listen((_) { if (mounted) setState(() => _step = (_step + 1) % widget.steps.length); });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black54,
      child: Center(
        child: AppCard(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(width: 60, height: 60, child: CircularProgressIndicator(
              strokeWidth: 4, valueColor: AlwaysStoppedAnimation(AppColors.lime), strokeCap: StrokeCap.round,
            )),
            const SizedBox(height: 24),
            Text('🤖 Claude AI', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.lime, fontFamily: 'Manrope')),
            const SizedBox(height: 8),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              child: Text(widget.steps[_step], key: ValueKey(_step),
                style: const TextStyle(fontSize: 14, color: AppColors.textMuted, fontFamily: 'Manrope'), textAlign: TextAlign.center,
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

// ─── Error Snackbar ───────────────────────────────────────────────────────────
void showError(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(fontFamily: 'Manrope')),
    backgroundColor: AppColors.red,
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
  ));
}

void showSuccess(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(fontFamily: 'Manrope')),
    backgroundColor: AppColors.green,
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
  ));
}
