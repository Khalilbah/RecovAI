#!/bin/bash
# ─── RecovAI Setup Script ─────────────────────────────────────────────────────
# شغّل هذا السكريبت لإعداد المشروع كاملاً
# Run: chmod +x setup.sh && ./setup.sh

set -e
CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║       RecovAI — Setup Script         ║${NC}"
echo -e "${CYAN}║  Flutter + Node.js + Claude AI       ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"
echo ""

# ─── Backend Setup ────────────────────────────────────────────────────────────
echo -e "${YELLOW}📦 Setting up Backend...${NC}"
cd backend

if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${GREEN}✅ .env created${NC}"
    echo ""
    echo -e "${YELLOW}⚠️  IMPORTANT: Add your Claude API key to backend/.env:${NC}"
    echo "   ANTHROPIC_API_KEY=sk-ant-your-key-here"
    echo ""
fi

npm install
echo -e "${GREEN}✅ Backend dependencies installed${NC}"

npm run setup
echo -e "${GREEN}✅ Database created and seeded${NC}"

cd ..

# ─── Flutter Setup ────────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}📱 Setting up Flutter...${NC}"
cd flutter

if command -v flutter &> /dev/null; then
    flutter pub get
    echo -e "${GREEN}✅ Flutter packages installed${NC}"
else
    echo -e "${YELLOW}⚠️  Flutter not found. Install from: https://flutter.dev/docs/get-started/install${NC}"
fi

cd ..

# ─── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                  ✅ Setup Complete!                  ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  Backend:                                            ║${NC}"
echo -e "${GREEN}║    cd backend && npm run dev                         ║${NC}"
echo -e "${GREEN}║    → http://localhost:3000                           ║${NC}"
echo -e "${GREEN}║                                                      ║${NC}"
echo -e "${GREEN}║  Flutter:                                            ║${NC}"
echo -e "${GREEN}║    cd flutter && flutter run                         ║${NC}"
echo -e "${GREEN}║                                                      ║${NC}"
echo -e "${GREEN}║  Build APK:                                          ║${NC}"
echo -e "${GREEN}║    cd flutter && flutter build apk --release         ║${NC}"
echo -e "${GREEN}║                                                      ║${NC}"
echo -e "${GREEN}║  Test accounts:                                      ║${NC}"
echo -e "${GREEN}║    Admin: khalilbba39@gmail.com / khalilbba3439      ║${NC}"
echo -e "${GREEN}║    User:  ahmed@demo.com / demo123456                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
